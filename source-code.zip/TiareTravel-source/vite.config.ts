import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/postcss';
import { fileURLToPath, URL } from 'node:url';

export default defineConfig({
 plugins: [react()],
 resolve: {alias: {'@': fileURLToPath(new URL('.', import.meta.url))}},
 css: {postcss: {plugins: [tailwindcss()]}},
 server: {
  host: '0.0.0.0', port: 4173, strictPort: true,
  allowedHosts: ['terminal.local'],
  proxy: {'/api': {target: 'http://127.0.0.1:3001'}, '/healthz': {target: 'http://127.0.0.1:3001'}}
 },
 build: {outDir:'dist', assetsDir:'', sourcemap:false}
});
