import test from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {resolve} from 'node:path';
import {createApp} from '../server/app.mjs';
import {defaultInput} from '../lib/travel.ts';

const password='pdf-test-manager-strong-password';
const fakePdf=Buffer.from('%PDF-1.7\n%%EOF');
const future=days=>new Date(Date.now()+days*86400000).toISOString();
const input=()=>({...structuredClone(defaultInput),date:future(60).slice(0,10),formats:['beach']});
const quote=()=>({amount:1250000,source:'https://example.com/PRIVATE_COST_SOURCE',travelDate:future(60).slice(0,10),scope:'Все перелёты, проживание, трансферы, питание, сборы и страхование для двух взрослых.',availability:'Номер и места на рейсе подтверждены поставщиком.',terms:'Оплата по договору агентства; условия и сроки отмены согласованы с поставщиком.',validUntil:future(2)});

async function fixture(t,pdfRenderer){
 const app=await createApp({env:{NODE_ENV:'test',TEST_SQLITE_PATH:':memory:',MANAGER_PASSWORD:password,APP_BASE_URL:'http://localhost',MAIL_MODE:'test',STATIC_DIR:resolve('public')},startOutbox:false,...(pdfRenderer?{pdfRenderer}:{})});
 await new Promise(done=>app.server.listen(0,'127.0.0.1',done));const base=`http://127.0.0.1:${app.server.address().port}`;t.after(()=>app.close());
 function client(){let cookie='';return {async call(path='/api/workspace',body){const response=await fetch(base+path,{method:body===undefined?'GET':'POST',headers:{...(cookie?{Cookie:cookie}:{}),...(body===undefined?{}:{'Content-Type':'application/json',Origin:'http://localhost'})},...(body===undefined?{}:{body:JSON.stringify(body)})});const setCookie=response.headers.get('set-cookie');if(setCookie)cookie=setCookie.split(';')[0];const bytes=Buffer.from(await response.arrayBuffer());return {status:response.status,headers:response.headers,bytes,data:response.headers.get('content-type')?.includes('application/json')?JSON.parse(bytes.toString()):null};}};}
 const customer=client(),manager=client();assert.equal((await manager.call('/api/auth/login',{password})).status,200);return {...app,customer,manager,client};
}
const pdfPath=(r,mode='client',candidateId)=>`/api/requests/${r.id}/proposal.pdf?mode=${mode}&revision=${r.revision}${candidateId?'&candidateId='+candidateId:''}`;
async function getRequest(f,id){return (await f.manager.call()).data.requests.find(r=>r.id===id);}
async function createRequest(f,patch={}){const data={action:'create_request',id:randomUUID(),input:input(),customerName:'Елена · персональное путешествие',customerEmail:'PRIVATE_EMAIL@example.com',contact:'PRIVATE_CONTACT',notes:'PRIVATE_REQUEST_NOTES',...patch};assert.equal((await f.customer.call('/api/workspace',data)).status,200);return getRequest(f,data.id);}
async function publish(f,r){const candidate=r.candidates.find(c=>!c.issues.length&&!c.review.length);assert.ok(candidate);assert.equal((await f.manager.call('/api/workspace',{action:'publish_candidate',id:r.id,revision:r.revision,candidateId:candidate.id,managerNote:'Публичный комментарий: спокойная программа и подтверждение цены после выбора.'})).status,200);return getRequest(f,r.id);}
async function prepareQuote(f,r){r=await publish(f,r);assert.equal((await f.customer.call('/api/workspace',{action:'select_request',id:r.id,revision:r.revision})).status,200);r=await getRequest(f,r.id);assert.equal((await f.manager.call('/api/workspace',{action:'update_request',id:r.id,revision:r.revision,status:'proposal',managerNote:r.managerNote,quote:quote()})).status,200);return getRequest(f,r.id);}

test('PDF: clients and anonymous visitors receive 403 before any travel-request read or rendering',async t=>{
 let renders=0;const f=await fixture(t,async()=>{renders++;return fakePdf;}),r=await createRequest(f);
 let requestReads=0;const query=f.db.query;f.db.query=async(sql,args)=>{if(/FROM travel_requests/i.test(sql))requestReads++;return query(sql,args);};
 for(const user of [f.customer,f.client()])assert.equal((await user.call(pdfPath(r,'review',r.candidates[0].id))).status,403);
 assert.equal(requestReads,0);assert.equal(renders,0);
});

test('PDF: strict query validation rejects duplicate, missing and malformed selectors',async t=>{
 let renders=0;const f=await fixture(t,async()=>{renders++;return fakePdf;}),r=await createRequest(f),base=`/api/requests/${r.id}/proposal.pdf`;
 for(const query of ['', '?mode=review','?revision=0','?mode=other&revision=0','?mode=review&revision=-1','?mode=review&revision=01','?mode=review&revision=1.2','?mode=review&revision=9007199254740992','?mode=review&revision=0&revision=0','?mode=review&revision=0&extra=1','?mode=review&revision=0&candidateId=broken','?mode=client&revision=0&candidateId='+r.candidates[0].id,'?mode=client&revision=0&candidateId='])assert.equal((await f.manager.call(base+query)).status,400,query);
 assert.equal((await f.manager.call('/api/requests/not-a-uuid/proposal.pdf?mode=review&revision=0')).status,400);assert.equal(renders,0);
});

test('PDF: saved candidate belongs to its request; missing and unpublished snapshots fail closed',async t=>{
 const f=await fixture(t,async()=>fakePdf),a=await createRequest(f),b=await createRequest(f);
 assert.equal((await f.manager.call(pdfPath(a,'review',b.candidates[0].id))).status,404);
 assert.equal((await f.manager.call(pdfPath({...a,id:randomUUID()},'review',a.candidates[0].id))).status,404);
 assert.equal((await f.manager.call(pdfPath(a,'review'))).status,409);
 assert.equal((await f.manager.call(pdfPath(a,'client'))).status,409);
 assert.equal((await f.manager.call(pdfPath({...a,revision:a.revision+1},'review',a.candidates[0].id))).status,409);
});

test('PDF: review exports actual saved candidate with conflicts and conditional estimates',async t=>{
 let model;const f=await fixture(t,async value=>{model=value;return fakePdf;}),r=await createRequest(f,{input:{...input(),budget:50000,excluded:'Мальдивы',directOnly:true}}),candidate=r.candidates[0];
 const result=await f.manager.call(pdfPath(r,'review',candidate.id));assert.equal(result.status,200);assert.equal(model.journey.id,candidate.journey.id);assert.ok(model.issues.length);assert.ok(model.review.length);assert.ok(model.estimate.low>0);assert.equal(model.estimate.kind,'demo');assert.equal(model.quote,null);
 assert.equal(result.headers.get('content-type'),'application/pdf');assert.equal(result.headers.get('cache-control'),'no-store');assert.equal(result.headers.get('content-disposition'),`inline; filename="TiareTravel-${r.id.slice(0,8)}-review-r0.pdf"`);
});

test('PDF: client model uses published snapshot and excludes drafts, internal details and indicative costs',async t=>{
 const models=[];const f=await fixture(t,async value=>{models.push(value);return fakePdf;});let r=await publish(f,await createRequest(f));const publishedTitle=r.journey.title;
 await f.manager.call('/api/workspace',{action:'save_internal_note',id:r.id,revision:r.revision,internalNote:'SECRET_INTERNAL_NOTE'});r=await getRequest(f,r.id);
 const candidate=r.candidates.find(c=>c.id===r.candidateId);
 await f.manager.call('/api/workspace',{action:'save_candidate',id:r.id,revision:r.revision,candidateId:candidate.id,journey:{...candidate.journey,title:'PRIVATE_EDITED_CANDIDATE',priceSource:'PRIVATE_ESTIMATE_SOURCE'}});r=await getRequest(f,r.id);
 await f.manager.call('/api/workspace',{action:'save_catalog',journey:{...r.journey,title:'DIFFERENT_GLOBAL_CATALOGUE'}});
 assert.equal((await f.manager.call(pdfPath(r))).status,200);const model=models.at(-1),serialized=JSON.stringify(model);
 assert.equal(model.journey.title,publishedTitle);assert.equal(model.estimate,null);assert.equal(model.quote,null);assert.deepEqual(model.issues,[]);assert.deepEqual(model.review,[]);
 assert.ok(!('budget'in model.input));assert.ok(!('excluded'in model.input));
 for(const key of ['perPersonFlight','roomNight','dailyMeals','groupLogistics','groupExperiences','priceKind','priceSource'])assert.ok(!(key in model.journey));
 for(const key of ['clientId','customerEmail','contact','notes','internalNote','candidates'])assert.ok(!(key in model));
 for(const secret of ['PRIVATE_EMAIL','PRIVATE_CONTACT','PRIVATE_REQUEST_NOTES','SECRET_INTERNAL_NOTE','PRIVATE_EDITED_CANDIDATE','PRIVATE_ESTIMATE_SOURCE','DIFFERENT_GLOBAL_CATALOGUE'])assert.ok(!serialized.includes(secret),secret);
});

test('PDF: only current complete quote is included; source stays internal and checkedAt never refreshes',async t=>{
 let model;const f=await fixture(t,async value=>{model=value;return fakePdf;});const r=await prepareQuote(f,await createRequest(f));
 assert.equal((await f.manager.call(pdfPath(r))).status,200);assert.equal(model.quote.amount,r.quote.amount);assert.equal(model.quote.checkedAt,r.quote.checkedAt);assert.ok(!('source'in model.quote));assert.ok(!JSON.stringify(model).includes('PRIVATE_COST_SOURCE'));
 assert.equal((await f.manager.call(pdfPath(r,'review'))).status,200);assert.equal(model.quote.source,r.quote.source);
 assert.equal((await f.manager.call(pdfPath(r,'review',r.candidateId))).status,200);assert.equal(model.quote,null);
 assert.equal((await getRequest(f,r.id)).quote.checkedAt,r.quote.checkedAt);
});

test('PDF: multi-stage published programme keeps its exact saved blocks and review flag',async t=>{
 let model;const f=await fixture(t,async value=>{model=value;return fakePdf;});let r=await createRequest(f,{input:{...input(),formats:['multi'],nights:8,budget:3000000}});
 const candidate=r.candidates.find(c=>c.journey.format==='multi'&&!c.issues.length);assert.ok(candidate);assert.equal(candidate.journey.needsReview,true);
 assert.equal((await f.manager.call('/api/workspace',{action:'publish_candidate',id:r.id,revision:r.revision,candidateId:candidate.id,managerNote:'Последовательность этапов и распределение ночей проверены; перелёты и цены подтвердим отдельно.'})).status,200);r=await getRequest(f,r.id);
 assert.equal((await f.manager.call(pdfPath(r))).status,200);assert.equal(model.journey.needsReview,true);assert.deepEqual(model.journey.program,candidate.journey.program);assert.equal(model.journey.program.length,r.journey.program.length);
});

test('PDF: candidate comment is saved with a new revision before publication and appears only in review',async t=>{
 let model;const f=await fixture(t,async value=>{model=value;return fakePdf;});let r=await createRequest(f);const candidateId=r.candidates[0].id,initialRevision=r.revision,note='Новый текст предложения: утро на пляже и прогулка после обеда.';
 const oldMail=(await f.db.query('SELECT * FROM email_outbox ORDER BY id')).rows;
 const saved=await f.manager.call('/api/workspace',{action:'save_candidate_note',id:r.id,revision:r.revision,candidateId,reviewNote:note});assert.equal(saved.status,200);assert.equal(saved.data.revision,initialRevision+1);r=await getRequest(f,r.id);
 assert.equal(r.candidates.find(c=>c.id===candidateId).reviewNote,note);assert.equal(r.status,'review');assert.equal(r.managerNote,'');assert.equal(r.journey,null);assert.equal(r.quote,null);assert.ok(r.history.some(h=>h.action==='save_candidate_note'));
 assert.deepEqual((await f.db.query('SELECT * FROM email_outbox ORDER BY id')).rows,oldMail);
 const client=(await f.customer.call()).data.requests[0];assert.ok(!JSON.stringify(client).includes(note));assert.equal(client.managerNote,'');
 assert.equal((await f.manager.call(pdfPath({...r,revision:initialRevision},'review',candidateId))).status,409);
 assert.equal((await f.manager.call(pdfPath(r,'review',candidateId))).status,200);assert.equal(model.managerNote,note);
 assert.equal((await f.manager.call(pdfPath(r))).status,409);
});

test('PDF: draft comment stays separate from published proposal and survives candidate edits',async t=>{
 let model;const f=await fixture(t,async value=>{model=value;return fakePdf;});let r=await prepareQuote(f,await createRequest(f));const publishedComment=r.managerNote,publishedJourney=r.journey,publishedQuote=r.quote,candidateId=r.candidateId,note='DRAFT_NOTE_NOT_FOR_CLIENT: новый вариант комментария к будущему предложению.';
 const mailBefore=(await f.db.query('SELECT * FROM email_outbox ORDER BY id')).rows;
 assert.equal((await f.manager.call('/api/workspace',{action:'save_candidate_note',id:r.id,revision:r.revision,candidateId,reviewNote:note})).status,200);r=await getRequest(f,r.id);
 const candidate=r.candidates.find(c=>c.id===candidateId);
 assert.equal((await f.manager.call('/api/workspace',{action:'save_candidate',id:r.id,revision:r.revision,candidateId,journey:{...candidate.journey,title:'Отредактированный будущий маршрут'}})).status,200);r=await getRequest(f,r.id);
 assert.equal(r.candidates.find(c=>c.id===candidateId).reviewNote,note);assert.equal(r.status,'proposal');assert.equal(r.managerNote,publishedComment);assert.deepEqual(r.journey,publishedJourney);assert.deepEqual(r.quote,publishedQuote);assert.deepEqual((await f.db.query('SELECT * FROM email_outbox ORDER BY id')).rows,mailBefore);
 assert.equal((await f.manager.call(pdfPath(r,'review',candidateId))).status,200);assert.equal(model.managerNote,note);
 assert.equal((await f.manager.call(pdfPath(r))).status,200);assert.equal(model.managerNote,publishedComment);assert.ok(!JSON.stringify(model).includes(note));assert.ok(!JSON.stringify((await f.customer.call()).data).includes(note));
});

test('PDF: draft comment writes enforce manager role, candidate ownership, revision and length',async t=>{
 const f=await fixture(t,async()=>fakePdf);let r=await createRequest(f);const other=await createRequest(f);const data={action:'save_candidate_note',id:r.id,revision:r.revision,candidateId:r.candidates[0].id,reviewNote:'Комментарий к сохранённому варианту.'};
 assert.equal((await f.customer.call('/api/workspace',data)).status,403);
 assert.equal((await f.manager.call('/api/workspace',{...data,candidateId:other.candidates[0].id})).status,404);
 assert.equal((await f.manager.call('/api/workspace',{...data,reviewNote:'x'.repeat(4001)})).status,400);
 assert.equal((await f.manager.call('/api/workspace',data)).status,200);
 assert.equal((await f.manager.call('/api/workspace',{...data,reviewNote:'Попытка перезаписи старой версии'})).status,409);
 r=await getRequest(f,r.id);assert.equal(r.candidates.find(c=>c.id===data.candidateId).reviewNote,data.reviewNote);
});

test('PDF: legacy published comment never transfers to a different candidate',async t=>{
 let model;const f=await fixture(t,async value=>{model=value;return fakePdf;}),r=await publish(f,await createRequest(f)),other=r.candidates.find(c=>c.id!==r.candidateId);assert.ok(other);assert.equal(other.reviewNote,undefined);
 const legacyCandidates=r.candidates.map(({reviewNote,...candidate})=>candidate);await f.db.query('UPDATE travel_requests SET candidates_json=? WHERE id=?',[JSON.stringify(legacyCandidates),r.id]);
 assert.equal((await f.manager.call(pdfPath(r,'review',r.candidateId))).status,200);assert.equal(model.managerNote,r.managerNote);
 assert.equal((await f.manager.call(pdfPath(r,'review',other.id))).status,200);assert.equal(model.managerNote,'');
 assert.equal((await f.manager.call(pdfPath(r))).status,200);assert.equal(model.managerNote,r.managerNote);
});

test('PDF: publication atomically saves the latest comment for both published and review snapshots',async t=>{
 let model;const f=await fixture(t,async value=>{model=value;return fakePdf;});let r=await createRequest(f);const candidateId=r.candidates.find(c=>!c.issues.length&&!c.review.length).id;
 const oldNote='Комментарий A: сохранённый первоначальный черновик.',newNote='Комментарий B: последняя редакция, которую менеджер публикует клиенту.';
 assert.equal((await f.manager.call('/api/workspace',{action:'save_candidate_note',id:r.id,revision:r.revision,candidateId,reviewNote:oldNote})).status,200);r=await getRequest(f,r.id);const draftRevision=r.revision;
 assert.equal((await f.manager.call('/api/workspace',{action:'publish_candidate',id:r.id,revision:r.revision,candidateId,managerNote:newNote})).status,200);r=await getRequest(f,r.id);
 assert.equal(r.revision,draftRevision+1);assert.equal(r.managerNote,newNote);assert.equal(r.candidates.find(c=>c.id===candidateId).reviewNote,newNote);
 assert.equal((await f.manager.call(pdfPath(r,'review',candidateId))).status,200);assert.equal(model.managerNote,newNote);
 assert.equal((await f.manager.call(pdfPath(r))).status,200);assert.equal(model.managerNote,newNote);
 const oldVersion=JSON.parse((await f.db.query('SELECT snapshot_json FROM request_versions WHERE request_id=? AND revision=?',[r.id,draftRevision])).rows[0].snapshot_json);assert.equal(oldVersion.candidates.find(c=>c.id===candidateId).reviewNote,oldNote);
});

test('PDF: expired, invalid, future-checked, over-budget and mismatched-date quotes are suppressed',async t=>{
 let model;const f=await fixture(t,async value=>{model=value;return fakePdf;}),r=await prepareQuote(f,await createRequest(f));
 const invalid=[{validUntil:future(-1)},{checkedAt:future(1)},{amount:r.input.budget+1},{travelDate:future(70).slice(0,10)},{travelDate:'2026-02-30'},{source:'http://example.com'},{scope:'неполно'},{validUntil:future(70)}];
 for(const patch of invalid){await f.db.query('UPDATE travel_requests SET quote_json=? WHERE id=?',[JSON.stringify({...r.quote,...patch}),r.id]);assert.equal((await f.manager.call(pdfPath(r))).status,200);assert.equal(model.quote,null,JSON.stringify(patch));}
 await f.db.query('UPDATE travel_requests SET quote_json=?,status=? WHERE id=?',[JSON.stringify(r.quote),'pricing',r.id]);assert.equal((await f.manager.call(pdfPath(r))).status,200);assert.equal(model.quote,null);
});

test('PDF: exporting never publishes, selects, records history or queues email',async t=>{
 const f=await fixture(t,async()=>fakePdf),r=await createRequest(f);const before=(await f.db.query('SELECT * FROM travel_requests WHERE id=?',[r.id])).rows[0];const countBefore=(await f.db.query('SELECT COUNT(*) AS total FROM request_versions')).rows[0].total;const mailBefore=(await f.db.query('SELECT COUNT(*) AS total FROM email_outbox')).rows[0].total;
 assert.equal((await f.manager.call(pdfPath(r,'review',r.candidates[0].id))).status,200);
 assert.deepEqual((await f.db.query('SELECT * FROM travel_requests WHERE id=?',[r.id])).rows[0],before);assert.equal((await f.db.query('SELECT COUNT(*) AS total FROM request_versions')).rows[0].total,countBefore);assert.equal((await f.db.query('SELECT COUNT(*) AS total FROM email_outbox')).rows[0].total,mailBefore);
});

test('PDF: only one render runs per process; slot is released after a failure',async t=>{
 let finish,entered;const rendering=new Promise(resolve=>{entered=resolve;});let calls=0;
 const f=await fixture(t,async()=>{calls++;if(calls===1){entered();await new Promise(resolve=>{finish=resolve;});throw new Error('INTERNAL_RENDER_ERROR');}return fakePdf;}),r=await createRequest(f),path=pdfPath(r,'review',r.candidates[0].id);
 const first=f.manager.call(path);await rendering;
 try{const busy=await f.manager.call(path);assert.equal(busy.status,429);assert.equal(busy.headers.get('retry-after'),'5');assert.equal(calls,1);}finally{finish();}
 const failed=await first;assert.equal(failed.status,503);assert.ok(!failed.data.error.includes('INTERNAL_RENDER_ERROR'));assert.equal((await f.manager.call(path)).status,200);
});

test('PDF: changing request while rendering rejects the stale output',async t=>{
 let finish,entered;const rendering=new Promise(resolve=>{entered=resolve;});const f=await fixture(t,async()=>{entered();await new Promise(resolve=>{finish=resolve;});return fakePdf;}),r=await createRequest(f);
 const result=f.manager.call(pdfPath(r,'review',r.candidates[0].id));await rendering;
 try{assert.equal((await f.manager.call('/api/workspace',{action:'save_internal_note',id:r.id,revision:r.revision,internalNote:'Updated during render'})).status,200);}finally{finish();}
 assert.equal((await result).status,409);
});

test('PDF: quote expiring during render rejects that file and a repeat exports without stale price',async t=>{
 let finish,entered,model,calls=0;const rendering=new Promise(resolve=>{entered=resolve;});
 const f=await fixture(t,async value=>{model=value;calls++;if(calls===1){entered();await new Promise(resolve=>{finish=resolve;});}return fakePdf;}),r=await prepareQuote(f,await createRequest(f));
 const expiresAt=Date.now()+1000;await f.db.query('UPDATE travel_requests SET quote_json=? WHERE id=?',[JSON.stringify({...r.quote,validUntil:new Date(expiresAt).toISOString()}),r.id]);
 const pending=f.manager.call(pdfPath(r));await rendering;
 try{assert.ok(model.quote);await new Promise(resolve=>setTimeout(resolve,Math.max(0,expiresAt-Date.now())+30));}finally{finish();}
 const expired=await pending;assert.equal(expired.status,409);assert.match(expired.data.error,/истёк/);
 assert.equal((await f.manager.call(pdfPath(r))).status,200);assert.equal(model.quote,null);
});

test('PDF: real renderer returns a complete PDF with embedded fonts and Unicode mappings',async t=>{
 const f=await fixture(t),r=await publish(f,await createRequest(f));const result=await f.manager.call(pdfPath(r));
 assert.equal(result.status,200,JSON.stringify(result.data));assert.ok(result.bytes.subarray(0,5).equals(Buffer.from('%PDF-')));assert.match(result.bytes.subarray(-64).toString('ascii'),/%%EOF/);assert.ok(result.bytes.length>20000);assert.ok(result.bytes.length<16*1024*1024);
 const structuralText=result.bytes.toString('latin1');assert.match(structuralText,/\/FontFile(?:2|3)\b/);assert.match(structuralText,/\/ToUnicode\b/);
});
