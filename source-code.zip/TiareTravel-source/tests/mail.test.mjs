import test from 'node:test';
import assert from 'node:assert/strict';
import {buildManagerRequestEmail,buildClientProposalEmail,sendResendEmail,getResendEmail,EmailProviderError,RESEND_TIMEOUT_MS,RESEND_IDEMPOTENCY_WINDOW_MS} from '../server/mail.mjs';

const id='12345678-1234-4123-8123-123456789abc';
const providerId='49a3999c-0ce1-4ea6-ab68-afcd6dc2e794';
const journey={id:'island-calm',title:'Остров <солнца> & море',country:'Мальдивы',destinations:['Мале','Остров'],overview:'Маршрут у моря с индивидуальной программой.',hotel:[{name:'Отель <название>',room:'Вилла "Лагуна"',location:'Остров',description:'Описание без неподтверждённых обещаний.',url:'https://hotel.example/'}],program:[{title:'Знакомство',activity:'Прогулка у лагуны.',evening:'Спокойный вечер.'}],includes:['Проживание'],excludes:['Дополнительные услуги'],logistics:'Трансфер проверяется менеджером.',season:'Погодные условия уточняются для дат.',documents:'Документы проверяются индивидуально.',tradeoff:'Зависимость программы от погоды.',priceKind:'demo',priceSource:'SECRET_SUPPLIER_PRICE_SOURCE',perPersonFlight:999991,roomNight:888882};
const input={formats:['beach'],destination:'Мальдивы',excluded:'Неизвестный остров',departure:'Москва',date:'2099-10-01',nights:7,adults:2,children:[],budget:1500000,priorities:['nature','quiet'],pace:'calm',cabin:'business',directOnly:true,maxHours:9,special:'Особый запрос <script>alert(1)</script>',hotelChanges:1};
const request={id,input,customerName:'Анна <img src=x onerror=alert(1)>',customerEmail:'client@example.com',contact:'+7 999 123 45 67',notes:'Комментарий & пожелание',managerNote:'Публичный комментарий менеджера.',internalNote:'INTERNAL_NOTE_NEVER_CLIENT',journey,status:'selection',quote:null,candidates:[{private:'INTERNAL_CANDIDATES_NEVER_CLIENT'}]};
const candidate={id:'1',journey,estimate:{low:1000000,high:1180000,kind:'demo',source:'INTERNAL_ESTIMATE_SOURCE'},matches:['nature'],issues:['Верхняя граница превышает бюджет'],review:['Проверить прямой рейс'],rationale:'Соответствует интересу к природе.'};
const appUrl='https://tiare.example/base?token=DO_NOT_PROPAGATE#secret';
const mailArgs={apiKey:'re_test_key',from:'Tiare Travel <travel@example.com>',to:'manager@example.com',replyTo:'client@example.com',subject:'Тестовое письмо',html:'<p>Привет</p>',text:'Привет',idempotencyKey:'request/123/manager-v1'};
const response=(data,status=200,headers={})=>({ok:status>=200&&status<300,status,headers:new Headers(headers),json:async()=>data});
const freshQuote=()=>({amount:1234567,source:'https://supplier.example/INTERNAL_QUOTE_SOURCE',travelDate:'2099-10-01',scope:'Перелёт, проживание и трансфер на всех участников.',availability:'Номер доступен на момент проверки.',terms:'Оплата после согласования; условия отмены приложены.',checkedAt:new Date(Date.now()-60000).toISOString(),validUntil:new Date(Date.now()+86400000).toISOString()});

test('manager email escapes HTML, contains request constraints and at most five candidates',()=>{
  const mail=buildManagerRequestEmail({request,candidates:Array.from({length:7},(_,i)=>({...candidate,journey:{...journey,title:`Кандидат ${i+1}`}})),appUrl});
  assert.ok(mail.html.includes('&lt;img src=x onerror=alert(1)&gt;'));
  assert.ok(mail.html.includes('&lt;script&gt;alert(1)&lt;/script&gt;'));
  assert.ok(!mail.html.includes('<script>'));
  for(const item of ['Кандидат 5','Неизвестный остров','Проверить прямой рейс','превышает бюджет','ДЕМОНСТРАЦИОННЫЙ РАСЧЁТ','не более 9 ч','Вилла'])assert.ok(mail.text.includes(item),item);
  assert.ok(!mail.text.includes('Кандидат 6'));
  assert.ok(mail.html.includes(`?view=agent&amp;request=${id}`));
  assert.ok(!mail.html.includes('DO_NOT_PROPAGATE'));
  assert.ok(!/[\r\n]/.test(mail.subject));
});

test('manager no-match message does not invent candidates',()=>{
  const mail=buildManagerRequestEmail({request,candidates:[],appUrl});
  assert.match(mail.text,/Готовых вариантов.*пока нет/);
  assert.ok(!mail.text.includes(journey.title));
});

test('manager agreement email prioritizes the chosen journey and current conditions, never draft candidates',()=>{
  const q=freshQuote();
  const mail=buildManagerRequestEmail({request:{...request,status:'agreed',quote:q},candidates:[{...candidate,journey:{...journey,title:'UNRELATED_PRIVATE_DRAFT'}}],appUrl});
  assert.match(mail.subject,/клиент согласовал/);
  assert.ok(mail.html.includes('Клиент согласовал путешествие'));
  assert.ok(mail.text.includes('Заявка передана на оформление'));
  assert.ok(mail.text.includes(journey.title));
  assert.match(mail.text,/1\s234\s567/);
  for(const expected of [q.scope,q.availability,q.terms,'2099','Проверено менеджером','Предложение действует до','Отель <название>','Открыть заявку для оформления'])assert.ok(mail.text.includes(expected),expected);
  for(const forbidden of ['UNRELATED_PRIVATE_DRAFT','Новая заявка','ДЕМОНСТРАЦИОННЫЙ РАСЧЁТ'])assert.ok(!mail.text.includes(forbidden),forbidden);
  assert.ok(mail.html.includes('войдите в кабинет менеджера'));
  const expired=buildManagerRequestEmail({request:{...request,status:'agreed',quote:{...q,validUntil:new Date(Date.now()-1000).toISOString()}},candidates:[candidate],appUrl});
  assert.ok(expired.text.includes('Повторно проверьте условия перед оформлением'));
  assert.ok(!expired.text.includes('СОГЛАСОВАННЫЕ УСЛОВИЯ'));
  assert.doesNotMatch(expired.text,/1\s234\s567/);
});

test('client refuses unpublished drafts even when they contain a journey',()=>{
  for(const status of ['review','new','unknown'])assert.throws(()=>buildClientProposalEmail({request:{...request,status},appUrl}),e=>e.code==='EMAIL_NOT_PUBLISHED');
  assert.throws(()=>buildClientProposalEmail({request:{...request,journey:null},appUrl}),e=>e.code==='EMAIL_NOT_PUBLISHED');
});

test('client receives only published content and no internal price or candidate data',()=>{
  const mail=buildClientProposalEmail({request:{...request,quote:freshQuote()},appUrl});
  for(const forbidden of ['INTERNAL_NOTE','INTERNAL_CANDIDATES','SECRET_SUPPLIER','INTERNAL_QUOTE_SOURCE','999991','888882','1 234 567']){
    assert.ok(!mail.text.includes(forbidden),forbidden);assert.ok(!mail.html.includes(forbidden),forbidden);
  }
  assert.ok(mail.html.includes('Остров &lt;солнца&gt; &amp; море'));
  assert.ok(mail.text.includes('Публичный комментарий менеджера'));
  assert.ok(mail.text.includes('демонстрационные суммы'));
  assert.ok(mail.text.includes(`?view=requests&request=${id}`));
  assert.ok(mail.html.includes('в том же браузере, в котором заполняли анкету'));
  assert.ok(mail.text.includes('в том же браузере, в котором заполняли анкету'));
  assert.ok(!mail.html.includes('войдите в сервис'));
  assert.ok(!mail.html.includes('войдите в кабинет'));
  assert.ok(!mail.text.includes('(вход в сервис)'));
});

test('current client quote states its verification time, validity and lack of booking',()=>{
  const mail=buildClientProposalEmail({request:{...request,status:'proposal',quote:freshQuote()},appUrl});
  assert.match(mail.text,/1\s234\s567/);
  assert.ok(mail.text.includes('СТОИМОСТЬ И УСЛОВИЯ'));
  assert.ok(mail.text.includes('Проверено менеджером'));
  assert.ok(mail.text.includes('МСК'));
  assert.ok(mail.text.includes('письмо не подтверждает бронирование'));
  assert.ok(!mail.text.includes('INTERNAL_QUOTE_SOURCE'));
});

test('expired, future-checked or incomplete quotes are never emailed as current prices',()=>{
  const quote=freshQuote();
  for(const patch of [{validUntil:new Date(Date.now()-1000).toISOString()},{checkedAt:new Date(Date.now()+1000).toISOString()},{availability:''},{source:'javascript:alert(1)'},{travelDate:'2099-02-30'}]){
    const mail=buildClientProposalEmail({request:{...request,status:'proposal',quote:{...quote,...patch}},appUrl});
    assert.ok(!mail.text.includes('СТОИМОСТЬ И УСЛОВИЯ'));
    assert.ok(mail.text.includes('требуют повторного подтверждения'));
  }
});

test('email links reject unsafe origins and credentials',()=>{
  for(const bad of ['javascript:alert(1)','http://evil.example','https://user:secret@tiare.example'])assert.throws(()=>buildManagerRequestEmail({request,appUrl:bad}),e=>e.code==='EMAIL_INVALID_APP_URL');
  const local=buildManagerRequestEmail({request,appUrl:'http://terminal.local:4173'});
  assert.ok(local.text.includes(`http://terminal.local:4173/?view=agent&request=${id}`));
});

test('Resend send uses documented JSON and idempotency header and reports accepted only',async()=>{
  let call;
  const result=await sendResendEmail({...mailArgs,fetchImpl:async(...args)=>{call=args;return response({id:providerId});}});
  assert.deepEqual(result,{id:providerId,status:'accepted'});
  assert.equal(call[0],'https://api.resend.com/emails');
  assert.equal(call[1].method,'POST');assert.equal(call[1].redirect,'error');
  assert.equal(call[1].headers['Idempotency-Key'],mailArgs.idempotencyKey);
  const payload=JSON.parse(call[1].body);
  assert.deepEqual(payload,{from:mailArgs.from,to:[mailArgs.to],subject:mailArgs.subject,html:mailArgs.html,text:mailArgs.text,reply_to:[mailArgs.replyTo]});
  assert.equal(RESEND_IDEMPOTENCY_WINDOW_MS,86400000);
});

test('invalid recipients, headers and absent configuration fail before network',async()=>{
  let calls=0;
  for(const patch of [{to:'bad\r\nBcc: evil@example.com'},{subject:'Subject\nBcc: evil@example.com'},{idempotencyKey:''},{apiKey:''}])await assert.rejects(sendResendEmail({...mailArgs,...patch,fetchImpl:async()=>{calls++;return response({id:providerId});}}),EmailProviderError);
  assert.equal(calls,0);
});

test('provider errors are sanitized and rate limits preserve Retry-After',async()=>{
  await assert.rejects(sendResendEmail({...mailArgs,fetchImpl:async()=>response({name:'rate_limit_exceeded',message:'SECRET '+mailArgs.apiKey+' client@example.com'},429,{'Retry-After':'9'})}),e=>{
    assert.equal(e.status,429);assert.equal(e.retryable,true);assert.equal(e.ambiguous,false);assert.equal(e.retryAfterSeconds,9);
    assert.ok(!JSON.stringify(e).includes('SECRET'));assert.ok(!JSON.stringify(e).includes(mailArgs.apiKey));return true;
  });
});

test('permanent idempotency conflicts differ from safe retry of concurrent attempts',async()=>{
  for(const [name,retryable,ambiguous] of [['invalid_idempotent_request',false,false],['concurrent_idempotent_requests',true,true]])await assert.rejects(sendResendEmail({...mailArgs,fetchImpl:async()=>response({name},409)}),e=>e.retryable===retryable&&e.ambiguous===ambiguous);
});

test('network errors and server failures retain ambiguous delivery state',async()=>{
  for(const fetchImpl of [async()=>{throw new Error('secret provider URL');},async()=>response({name:'application_error'},500),async()=>response({unexpected:'shape'})])await assert.rejects(sendResendEmail({...mailArgs,fetchImpl}),e=>e.retryable&&e.ambiguous&&!e.message.includes('secret'));
});

test('8-second timeout aborts a stalled transport without claiming failure or delivery',async t=>{
  t.mock.timers.enable({apis:['setTimeout']});
  let signal;
  const promise=sendResendEmail({...mailArgs,fetchImpl:async(_url,options)=>{signal=options.signal;return new Promise(()=>{});}});
  const rejection=assert.rejects(promise,e=>e.code==='RESEND_TIMEOUT'&&e.retryable&&e.ambiguous);
  t.mock.timers.tick(RESEND_TIMEOUT_MS);
  await rejection;
  assert.equal(signal.aborted,true);
});

test('delivery lookup distinguishes accepted, delivered, bounced and provider events',async()=>{
  for(const [event,status] of [['sent','accepted'],['delivery_delayed','accepted'],['delivered','delivered'],['bounced','bounced'],['complained','complained'],['suppressed','failed'],['unknown_new_event','unknown']]){
    const result=await getResendEmail({apiKey:mailArgs.apiKey,id:providerId,fetchImpl:async(url,options)=>{
      assert.equal(url,`https://api.resend.com/emails/${providerId}`);assert.equal(options.method,'GET');
      return response({id:providerId,last_event:event,created_at:'2026-09-23T10:00:00Z',html:'SECRET_BODY',to:['secret@example.com']});
    }});
    assert.equal(result.status,status);assert.ok(!JSON.stringify(result).includes('SECRET_BODY'));assert.ok(!JSON.stringify(result).includes('secret@example.com'));
  }
});

test('failed read is retryable without ambiguity about a new send',async()=>{
  await assert.rejects(getResendEmail({apiKey:mailArgs.apiKey,id:providerId,fetchImpl:async()=>{throw new Error('secret');}}),e=>e.retryable&&!e.ambiguous);
});
