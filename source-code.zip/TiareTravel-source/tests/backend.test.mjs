import test from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {mkdtemp,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createApp} from '../server/app.mjs';
import {createDatabase} from '../server/db.mjs';
import {defaultInput} from '../lib/travel.ts';

const password='test-manager-strong-password-42';
const future=days=>new Date(Date.now()+days*86400000).toISOString();
const input=()=>({...structuredClone(defaultInput),date:future(60).slice(0,10),formats:['beach']});
const quote=()=>({amount:1250000,source:'https://example.com/verified-quote',travelDate:future(60).slice(0,10),scope:'Полная стоимость перелётов, проживания, трансферов, питания, сборов и страхования для двух взрослых.',availability:'Номер и места на рейсе подтверждены поставщиком.',terms:'Бесплатная отмена до согласованного срока. Оплата по договору агентства.',validUntil:future(2)});

async function fixture(t,overrides={},providers){
 const app=await createApp({env:{NODE_ENV:'test',TEST_SQLITE_PATH:':memory:',MANAGER_PASSWORD:password,APP_BASE_URL:'http://localhost',MAIL_MODE:'test',...overrides},providers,startOutbox:false});
 await new Promise(resolve=>app.server.listen(0,'127.0.0.1',resolve));const base=`http://127.0.0.1:${app.server.address().port}`;
 t.after(()=>app.close());
 function client(){let cookie='';return {async call(path='/api/workspace',body,extra={}){const result=await fetch(base+path,{method:body===undefined?'GET':'POST',headers:{...(cookie?{Cookie:cookie}:{}),...(body!==undefined?{'Content-Type':'application/json',Origin:'http://localhost'}:{}),...extra},...(body!==undefined?{body:JSON.stringify(body)}:{})});const set=result.headers.get('set-cookie');if(set)cookie=set.split(';')[0];const text=await result.text();let data;try{data=JSON.parse(text);}catch{data=text;}return {status:result.status,data,cookie:set};},get cookie(){return cookie;}};}
 const customer=client(),manager=client();assert.equal((await manager.call('/api/auth/login',{password})).status,200);
 return {...app,customer,manager,client,base};
}
async function create(f,overrides={}){const data={action:'create_request',id:randomUUID(),input:input(),customerName:'Тестовый клиент',customerEmail:'client@example.com',contact:'',notes:'Проверка рабочего процесса',...overrides};const result=await f.customer.call('/api/workspace',data);assert.equal(result.status,200,JSON.stringify(result.data));return {data,result:result.data};}
async function managerRequest(f,id){return (await f.manager.call()).data.requests.find(r=>r.id===id);}
async function publish(f,id){const r=await managerRequest(f,id);const c=r.candidates.find(c=>!c.issues.length&&!c.review.length);assert.ok(c);const res=await f.manager.call('/api/workspace',{action:'publish_candidate',id,revision:r.revision,candidateId:c.id,managerNote:'Маршрут соответствует пожеланиям. Условия цены будут проверены после выбора.'});assert.equal(res.status,200,JSON.stringify(res.data));return managerRequest(f,id);}

test('Postgres is mandatory in Render; SQLite fallback is explicit and test-only',async()=>{
 await assert.rejects(()=>createDatabase({NODE_ENV:'production',TEST_SQLITE_PATH:':memory:'}),/DATABASE_URL/);
 await assert.rejects(()=>createDatabase({NODE_ENV:'test',TEST_SQLITE_PATH:':memory:',RENDER:'true'}),/DATABASE_URL/);
 await assert.rejects(()=>createDatabase({NODE_ENV:'test'}),/DATABASE_URL/);
});

test('client isolation, private manager candidates and no trusted ChatGPT header bypass',async t=>{
 const f=await fixture(t);const {data}=await create(f);
 const own=(await f.customer.call()).data;assert.equal(own.role,'client');assert.equal(own.catalog.length,0);assert.equal(own.requests[0].status,'review');assert.equal(own.requests[0].journey,null);assert.ok(!('candidates'in own.requests[0]));assert.ok(!('internalNote'in own.requests[0]));assert.ok(!('outbox'in own));
 const stranger=f.client(),other=await stranger.call('/api/workspace',undefined,{'x-chatgpt-user-id':'admin','x-chatgpt-email':'manager@example.com'});assert.equal(other.data.role,'client');assert.equal(other.data.requests.length,0);
 const denied=await stranger.call('/api/workspace',{action:'select_request',id:data.id,revision:0});assert.equal(denied.status,404);
 assert.equal((await stranger.call('/api/workspace',{action:'regenerate_candidates',id:data.id,revision:0})).status,403);
 const internal=await managerRequest(f,data.id);assert.ok(internal.candidates.length>0);assert.ok(internal.candidates.length<=5);assert.ok(internal.candidates.every(c=>c.rationale&&Array.isArray(c.issues)));
});

test('every request queues a durable blocked manager email without configuration; duplicate writes are idempotent',async t=>{
 const f=await fixture(t);const {data}=await create(f);assert.equal((await f.customer.call('/api/workspace',data)).data.duplicate,true);
 assert.equal((await f.customer.call('/api/workspace',{...data,notes:'Другие данные'})).status,409);
 const workspace=(await f.manager.call()).data;assert.equal(workspace.requests.length,1);assert.equal(workspace.outbox.length,1);assert.equal(workspace.outbox[0].status,'blocked');assert.ok(workspace.outbox[0].lastError.includes('RESEND_API_KEY'));assert.equal(workspace.mail.configured,false);
 const versions=await f.db.query('SELECT COUNT(*) AS n FROM request_versions');assert.equal(Number(versions.rows[0].n),1);
});

test('manager publishes a snapshot; client independently chooses and agrees after complete quote',async t=>{
 const f=await fixture(t);const {data}=await create(f);let r=await publish(f,data.id);assert.equal(r.status,'selection');
 assert.equal((await f.manager.call('/api/workspace',{action:'select_request',id:r.id,revision:r.revision})).status,403);
 assert.equal((await f.customer.call('/api/workspace',{action:'select_request',id:r.id,revision:r.revision})).status,200);r=await managerRequest(f,r.id);assert.equal(r.status,'pricing');
 const proposal=await f.manager.call('/api/workspace',{action:'update_request',id:r.id,revision:r.revision,status:'proposal',journeyId:r.journeyId,managerNote:r.managerNote,quote:quote()});assert.equal(proposal.status,200,JSON.stringify(proposal.data));r=await managerRequest(f,r.id);
 assert.equal((await f.manager.call('/api/workspace',{action:'agree_request',id:r.id,revision:r.revision})).status,403);
 assert.equal((await f.customer.call('/api/workspace',{action:'agree_request',id:r.id,revision:r.revision})).status,200);r=await managerRequest(f,r.id);assert.equal(r.status,'agreed');
 const workspace=(await f.manager.call()).data;assert.equal(workspace.outbox.filter(e=>e.kind==='manager').length,2);assert.equal(r.history.length,5);
});

test('hard constraints block publishing even with manager note; no silent budget or destination relaxation',async t=>{
 const f=await fixture(t);const {data}=await create(f,{input:{...input(),budget:50000,excluded:'Мальдивы'}});const r=await managerRequest(f,data.id);assert.ok(r.candidates.every(c=>c.issues.length));
 const result=await f.manager.call('/api/workspace',{action:'publish_candidate',id:r.id,revision:r.revision,candidateId:r.candidates[0].id,managerNote:'Всё проверено, но превышение бюджета не должно быть разрешено.'});assert.equal(result.status,409);assert.equal((await managerRequest(f,r.id)).status,'review');
});

test('complex request requires manager explanation and is hidden until explicit approval',async t=>{
 const f=await fixture(t);const {data}=await create(f,{input:{...input(),directOnly:true}});const r=await managerRequest(f,data.id),c=r.candidates.find(c=>!c.issues.length);assert.ok(c.review.length);
 assert.equal((await f.manager.call('/api/workspace',{action:'publish_candidate',id:r.id,revision:0,candidateId:c.id,managerNote:'Ок'})).status,400);
 assert.equal((await f.manager.call('/api/workspace',{action:'publish_candidate',id:r.id,revision:0,candidateId:c.id,managerNote:'Прямой перелёт на нужную дату проверен менеджером; время и тариф будут зафиксированы в предложении.'})).status,200);
 assert.ok((await f.customer.call()).data.requests[0].journey);
});

test('catalogue changes and draft edits never overwrite published request snapshot',async t=>{
 const f=await fixture(t);const {data}=await create(f);let r=await publish(f,data.id);const originalTitle=r.journey.title;
 assert.equal((await f.manager.call('/api/workspace',{action:'save_catalog',journey:{...r.journey,title:'Новый глобальный заголовок'}})).status,200);
 r=await managerRequest(f,r.id);assert.equal(r.journey.title,originalTitle);
 const candidate=r.candidates.find(c=>c.id===r.candidateId);assert.equal((await f.manager.call('/api/workspace',{action:'save_candidate',id:r.id,revision:r.revision,candidateId:candidate.id,journey:{...candidate.journey,title:'Личный черновик менеджера'}})).status,200);
 r=await managerRequest(f,r.id);assert.equal(r.journey.title,originalTitle);assert.equal(r.candidates.find(c=>c.id===candidate.id).journey.title,'Личный черновик менеджера');assert.equal((await f.customer.call()).data.requests[0].journey.title,originalTitle);
 const stale=await f.manager.call('/api/workspace',{action:'save_internal_note',id:r.id,revision:r.revision-1,internalNote:'Перезапись'});assert.equal(stale.status,409);
});

test('invalid, expired, mismatched-date and over-budget prices cannot become client proposals',async t=>{
 const f=await fixture(t);const {data}=await create(f);let r=await publish(f,data.id);await f.customer.call('/api/workspace',{action:'select_request',id:r.id,revision:r.revision});r=await managerRequest(f,r.id);
 for(const q of [{...quote(),amount:2000000},{...quote(),travelDate:future(70).slice(0,10)},{...quote(),validUntil:future(-1)},{...quote(),availability:''}]){const result=await f.manager.call('/api/workspace',{action:'update_request',id:r.id,revision:r.revision,status:'proposal',managerNote:r.managerNote,quote:q});assert.equal(result.status,400,JSON.stringify(result.data));}
 assert.equal((await managerRequest(f,r.id)).status,'pricing');
});

test('stale price cannot be agreed and replacement returns hidden drafts to review',async t=>{
 const f=await fixture(t);const {data}=await create(f);let r=await publish(f,data.id);await f.customer.call('/api/workspace',{action:'select_request',id:r.id,revision:r.revision});r=await managerRequest(f,r.id);
 assert.equal((await f.manager.call('/api/workspace',{action:'update_request',id:r.id,revision:r.revision,status:'proposal',managerNote:r.managerNote,quote:quote()})).status,200);r=await managerRequest(f,r.id);
 await f.db.query('UPDATE travel_requests SET quote_json=? WHERE id=?',[JSON.stringify({...r.quote,validUntil:future(-1)}),r.id]);
 assert.equal((await f.customer.call('/api/workspace',{action:'agree_request',id:r.id,revision:r.revision})).status,400);
 assert.equal((await f.manager.call('/api/workspace',{action:'update_request',id:r.id,revision:r.revision,status:'review',managerNote:'Нужно обновить тариф.',quote:null})).status,200);
 const client=(await f.customer.call()).data.requests[0];assert.equal(client.journey,null);assert.equal(client.quote,null);
});

test('test mode enforces safe recipient, explicit client send, immutable retries and accepted vs delivered states',async t=>{
 const sent=[];let calls=0;
 const f=await fixture(t,{RESEND_API_KEY:'fake-test-key',MAIL_FROM:'Tiare Test <test@example.com>',MANAGER_EMAIL:'manager@example.com',TEST_RECIPIENT_EMAIL:'test-only@example.com'},{async send(p){sent.push(p);calls++;if(calls===1)throw {code:'TIMEOUT',retryable:true,ambiguous:true};return {id:'provider-'+calls,status:'accepted'};},async get({id}){return {id,status:'delivered',reportedEvent:'delivered'};}});
 const {data}=await create(f);await f.outbox.drain();let workspace=(await f.manager.call()).data;assert.equal(workspace.outbox[0].status,'queued');await f.db.query('UPDATE email_outbox SET next_attempt_at=?',[future(-1)]);await f.outbox.drain();
 assert.equal(sent.length,2);assert.equal(sent[0].to,'test-only@example.com');assert.ok(sent[0].subject.startsWith('[ТЕСТ]'));assert.equal(sent[0].idempotencyKey,sent[1].idempotencyKey);assert.equal(sent[0].html,sent[1].html);
 workspace=(await f.manager.call()).data;assert.equal(workspace.outbox[0].status,'accepted');assert.equal(workspace.outbox[0].deliveredAt,null);
 assert.equal((await f.manager.call('/api/workspace',{action:'refresh_email',emailId:workspace.outbox[0].id})).status,200);assert.equal((await f.manager.call()).data.outbox[0].status,'delivered');
 const r=await publish(f,data.id);assert.equal((await f.manager.call()).data.outbox.length,1);
 assert.equal((await f.customer.call('/api/workspace',{action:'send_client_email',id:r.id,revision:r.revision})).status,403);
 assert.equal((await f.manager.call('/api/workspace',{action:'send_client_email',id:r.id,revision:r.revision})).status,200);assert.equal((await f.manager.call('/api/workspace',{action:'send_client_email',id:r.id,revision:r.revision})).status,200);await f.outbox.drain();
 workspace=(await f.manager.call()).data;assert.equal(workspace.outbox.length,2);assert.equal(sent.at(-1).to,'test-only@example.com');assert.ok(sent.at(-1).text.includes('client@example.com'));
});

test('ambiguous email retries stop after provider idempotency window',async t=>{
 let count=0;const f=await fixture(t,{RESEND_API_KEY:'fake',MAIL_FROM:'test@example.com',MANAGER_EMAIL:'manager@example.com',TEST_RECIPIENT_EMAIL:'test@example.com'},{async send(){count++;throw {code:'TIMEOUT',retryable:true,ambiguous:true};},async get(){throw new Error('unused');}});
 await create(f);await f.outbox.drain();await f.db.query('UPDATE email_outbox SET created_at=?,next_attempt_at=?',[future(-2),future(-1)]);await f.outbox.drain();assert.equal(count,1);const out=(await f.manager.call()).data.outbox[0];assert.equal(out.status,'unknown');assert.equal((await f.manager.call('/api/workspace',{action:'retry_email',emailId:out.id})).status,409);
});

test('manager authentication rotates sessions, limits guesses, logout removes manager role and rejects cross-site mutations',async t=>{
 const f=await fixture(t),client=f.client();const initial=await client.call();assert.match(initial.cookie,/HttpOnly/);assert.match(initial.cookie,/SameSite=Lax/);const before=client.cookie;assert.equal((await client.call('/api/auth/login',{password})).status,200);assert.notEqual(client.cookie,before);assert.equal((await client.call()).data.role,'manager');assert.equal((await client.call('/api/auth/logout',{})).status,200);assert.equal((await client.call()).data.role,'client');
 assert.equal((await client.call('/api/auth/login',{password},{Origin:'https://attacker.example'})).status,403);
 for(let i=0;i<5;i++)assert.equal((await client.call('/api/auth/login',{password:'incorrect'})).status,401);
 assert.equal((await client.call('/api/auth/login',{password})).status,429);
});

test('flat static distribution exposes only public assets and health actually checks database',async t=>{
 const dir=await mkdtemp(join(tmpdir(),'tiare-static-'));t.after(()=>rm(dir,{recursive:true,force:true}));await Promise.all([writeFile(join(dir,'index.html'),'<!doctype html><p>Tiare</p>'),writeFile(join(dir,'index-good123.js'),'console.log("ui")'),writeFile(join(dir,'tiare-server.mjs'),'SECRET'),writeFile(join(dir,'package.json'),'SECRET'),writeFile(join(dir,'source.zip'),'SECRET')]);
 const f=await fixture(t,{STATIC_DIR:dir});assert.equal((await f.customer.call('/')).status,200);assert.equal((await f.customer.call('/index-good123.js')).status,200);
 for(const path of ['/tiare-server.mjs','/package.json','/source.zip','/.env','/%2e%2e/package.json'])assert.equal((await f.customer.call(path)).status,404);
 assert.equal((await f.customer.call('/healthz')).data.database,'connected');
});
