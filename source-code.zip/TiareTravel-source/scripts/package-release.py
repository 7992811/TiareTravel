"""Create a flat, prebuilt GitHub/Render upload bundle. Run from the source root."""
from pathlib import Path
import json, shutil, subprocess, zipfile

root = Path(__file__).resolve().parent.parent
source_package = json.loads((root / 'package.json').read_text())
version = source_package['version']
archive_name = f'TiareTravel_GitHub_v{version}.zip'
brand_files = {
    'tiare-flower.svg', 'tiare-wordmark.svg',
    'tiare-display-latin.woff2', 'tiare-display-cyrillic.woff2',
    'FONT_LICENSES.txt',
}
missing_brand_files = sorted(name for name in brand_files if not (root / 'public' / name).is_file())
if missing_brand_files:
    raise RuntimeError('Missing brand assets or font license: ' + ', '.join(missing_brand_files))
release = root / 'release'
if release.exists(): shutil.rmtree(release)
release.mkdir()
subprocess.run(['npm', 'run', 'build'], cwd=root, check=True)
subprocess.run(['node', 'node_modules/vite/bin/vite.js', 'build', '--config', 'vite.server.config.ts'], cwd=root, check=True)
for path in (root / 'dist').iterdir():
    if not path.is_file(): raise RuntimeError('Expected a flat Vite asset directory')
    shutil.copy2(path, release / path.name)
for name in brand_files:
    if not (release / name).is_file(): raise RuntimeError('Brand asset missing from built release: ' + name)
package = {
    'name': source_package['name'], 'version': version, 'private': True,
    'type': 'module', 'engines': source_package['engines'],
    'scripts': {'start': 'node tiare-server.mjs'},
    'dependencies': {'pg': source_package['dependencies']['pg']}
}
(release / 'package.json').write_text(json.dumps(package, indent=2) + '\n')
subprocess.run(['npm', 'install', '--package-lock-only', '--ignore-scripts', '--no-audit', '--no-fund', '--fetch-retries=0', '--fetch-timeout=20000'], cwd=release, check=True)
blueprint = (root / 'render.yaml').read_text().replace('npm ci --include=dev && npm run build', 'npm ci --omit=dev')
blueprint = blueprint.replace('              - key: DATABASE_URL', '              - key: STATIC_DIR\n                value: .\n              - key: DATABASE_URL')
(release / 'render.yaml').write_text(blueprint)
readme = '''# TiareTravel — готовая сборка для GitHub и Render

Это комплект для загрузки с телефона. Все файлы должны лежать в корне репозитория.

## Загрузка с iPhone

1. Распаковать внешний архив __ARCHIVE_NAME__ в приложении «Файлы».
2. Открыть GitHub → TiareTravel → Add file → Upload files.
3. Выбрать все файлы из распакованного комплекта, загрузить с заменой совпадающих имён и нажать Commit changes. Загрузить нужно весь комплект, включая шрифты, логотипы и лицензии.
4. Архив source-code.zip загружать целиком: это резервная копия полного исходного проекта. Внешний архив повторно загружать не нужно.

## Запуск в Render

Открыть https://dashboard.render.com/select-repo?type=blueprint и выбрать репозиторий TiareTravel. Рабочее пространство — согласованное владельцем. Blueprint создаёт проект TiareTravel и среду Test.

В поля MANAGER_EMAIL и TEST_RECIPIENT_EMAIL указать один тестовый email. Приложение и PostgreSQL используют Free. После Deploy открыть ссылку сервиса. В Render → Environment хранится автоматически созданный MANAGER_PASSWORD; он нужен в «Кабинете агентства».

Для почты создать аккаунт Resend на тестовый email и добавить в Render → Environment ключ RESEND_API_KEY. Отправитель для первого теста — Tiare Travel Test <onboarding@resend.dev>. Такой отправитель работает только на email владельца Resend. Отправка клиентам на другие адреса требует подтверждённого домена.

До добавления ключа заявки сохраняются, а письма ожидают настройки в очереди. Состояние «Принято почтовым сервисом» отличается от «Доставлено».

## Что загружено

- tiare-server.mjs — собранный сервер, анкета и правила подбора.
- index.html, index-*.js, index-*.css — собранный интерфейс.
- lagoon.webp, favicon.svg, tiare-flower.svg и tiare-wordmark.svg — оформление и цветочный логотип.
- tiare-display-*.woff2 — локальные шрифты названия и заголовков; обращения к внешнему сервису шрифтов не нужны.
- FONT_LICENSES.txt — лицензия и атрибуция используемых шрифтов.
- package.json и package-lock.json — точные зависимости серверной части.
- render.yaml — конфигурация отдельной тестовой среды.
- source-code.zip — полные исходники, тесты и подробное описание.
- THIRD_PARTY_NOTICES.txt — лицензии компонентов сборки.

Сборка на Render выполняет только установку серверных зависимостей. Тяжёлая сборка интерфейса уже выполнена.

## Границы теста

Все заявки сначала видит менеджер. Варианты подбираются из стартовой коллекции семи шаблонов, а цены демонстрационные. Полная проверенная стоимость вводится менеджером отдельно. Бронирование и оплата в этой версии выполняются менеджером.

Клиент возвращается к заявке в том же браузере. Для восстановления доступа по email потребуется следующий этап разработки.

Бесплатная PostgreSQL Render действует 30 дней. Для продолжительной эксплуатации её необходимо перевести на постоянный тариф до истечения срока. Бесплатное приложение может засыпать после 15 минут без обращений; очередь хранится в базе и продолжает обработку после запуска.

При упаковке выполняются TypeScript и сборки клиента и сервера. Автоматические проверки запускаются отдельно командой npm test из исходного проекта. После обновления нужно проверить отображение цветка, названия и кириллицы на телефоне. Реальная доставка проверяется после добавления ключа Resend, реальный PostgreSQL — после запуска Render.

Документация: https://render.com/docs/free и https://resend.com/docs/knowledge-base/403-error-resend-dev-domain
'''
(release / 'README.md').write_text(readme.replace('__ARCHIVE_NAME__', archive_name))
notices = ['TiareTravel prebuilt distribution — third-party notices\n']
packages = []
for p in (root / 'node_modules').iterdir():
    if p.name.startswith('@') and p.is_dir(): packages.extend(x for x in p.iterdir() if x.is_dir())
    elif p.is_dir() and not p.name.startswith('.'): packages.append(p)
for p in sorted(packages):
    meta = p / 'package.json'
    if not meta.is_file(): continue
    info = json.loads(meta.read_text())
    license_paths = [f for f in p.iterdir() if f.is_file() and f.name.lower() in ['license','license.md','license.txt','licence','licence.md','copying']]
    if license_paths:
        notices.append('\n' + '=' * 70 + '\n' + str(info.get('name',p.name)) + ' ' + str(info.get('version','')) + '\n')
        notices.extend(f.read_text(errors='replace') for f in license_paths)
(release / 'THIRD_PARTY_NOTICES.txt').write_text('\n'.join(notices))
exclude = {'node_modules','dist','release','.git','qa','data','.sites-runtime','.wrangler','__pycache__'}
with zipfile.ZipFile(release / 'source-code.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(root.rglob('*')):
        rel = path.relative_to(root)
        if not path.is_file() or any(p in exclude for p in rel.parts): continue
        if path.name.startswith('.env') and path.name != '.env.example': continue
        if path.suffix in ['.sqlite','.db','.log','.pyc']: continue
        archive.write(path, Path('TiareTravel-source') / rel)
print('Release files:')
for path in sorted(release.iterdir()): print(path.name, path.stat().st_size)
