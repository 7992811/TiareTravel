import {spawn} from 'node:child_process';
import {existsSync} from 'node:fs';
if(existsSync('.env')) process.loadEnvFile('.env');
const children = [
 spawn(process.execPath, ['--watch','server/index.mjs'], {stdio:'inherit',env:{...process.env,PORT:process.env.PORT||'3001'}}),
 spawn(process.execPath, ['node_modules/vite/bin/vite.js','--host','0.0.0.0','--port','4173','--strictPort'],{stdio:'inherit',env:process.env})
];
let stopping=false;
function stop(code=0){if(stopping)return;stopping=true;for(const child of children)child.kill('SIGTERM');setTimeout(()=>process.exit(code),500).unref();}
for(const child of children)child.on('exit',code=>stop(code||0));
process.on('SIGINT',()=>stop());process.on('SIGTERM',()=>stop());
