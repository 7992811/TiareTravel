/**
 * Tiare Travel transactional mail. Native Node only; this module never retries.
 * Persist the generated payload and key in the outbox before sending it.
 * Resend idempotency expires after 24 hours: an ambiguous attempt must not be
 * retried automatically outside that window.
 * https://resend.com/docs/api-reference/emails/send-email
 * https://resend.com/docs/api-reference/emails/retrieve-email
 * https://resend.com/docs/dashboard/emails/idempotency-keys
 */

export const RESEND_TIMEOUT_MS = 8000;
export const RESEND_IDEMPOTENCY_WINDOW_MS = 24 * 60 * 60 * 1000;
const API = 'https://api.resend.com/emails';
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const FORMAT = {beach:'Острова и море',city:'Города и культура',multi:'Несколько мест',safari:'Сафари и природа',cruise:'Круизы и экспедиции'};
const PRIORITY = {quiet:'Тишина и приватность',food:'Гастрономия',culture:'Культура',nature:'Природа',comfort:'Комфорт',activity:'Новые впечатления'};
const PACE = {calm:'Спокойный',balanced:'Сбалансированный',active:'Насыщенный'};
const raw = (value, max = 3000) => String(value ?? '').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').slice(0,max).trim();
const oneLine = (value, max = 160) => raw(value,max).replace(/[\r\n]+/g,' ').replace(/\s+/g,' ');
const esc = value => raw(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const paragraphs = value => esc(value).replace(/\r?\n/g,'<br>');
const list = value => Array.isArray(value) ? value : [];
const currency = value => Number.isFinite(value) ? new Intl.NumberFormat('ru-RU',{style:'currency',currency:'RUB',maximumFractionDigits:0}).format(value) : 'Не рассчитано';
const defined = (value,fallback='Не указано') => raw(value)||fallback;
const dateOnlyValid = value => typeof value==='string' && /^\d{4}-\d{2}-\d{2}$/.test(value) && Number.isFinite(Date.parse(value)) && new Date(value).toISOString().slice(0,10)===value;
const day = value => dateOnlyValid(value) ? new Intl.DateTimeFormat('ru-RU',{timeZone:'UTC',day:'numeric',month:'long',year:'numeric'}).format(new Date(value)) : 'Даты уточняются';
const instantValid = value => typeof value==='string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d{1,3})?)?(Z|[+-]\d{2}:\d{2})$/.test(value) && Number.isFinite(Date.parse(value));
const instant = value => instantValid(value) ? new Intl.DateTimeFormat('ru-RU',{timeZone:'Europe/Moscow',day:'numeric',month:'long',year:'numeric',hour:'2-digit',minute:'2-digit'}).format(new Date(value))+' МСК' : 'Время не подтверждено';

export class EmailProviderError extends Error {
  constructor(code, {status=0,retryable=false,ambiguous=false,retryAfterSeconds=null,message='Не удалось выполнить операцию с почтовым сервисом.'}={}) {
    super(message);
    this.name='EmailProviderError';
    this.code=code;
    this.status=status;
    this.retryable=retryable;
    this.ambiguous=ambiguous;
    this.retryAfterSeconds=retryAfterSeconds;
  }
  toJSON() {
    return {name:this.name,code:this.code,message:this.message,status:this.status,retryable:this.retryable,ambiguous:this.ambiguous,retryAfterSeconds:this.retryAfterSeconds};
  }
}

function invalid(code='EMAIL_INVALID_INPUT',message='Проверьте настройки отправки письма.') {
  return new EmailProviderError(code,{message});
}
function safePublicUrl(value) {
  try {
    const url = new URL(value);
    if (url.protocol!=='https:' || url.username || url.password) return null;
    return url.toString();
  } catch {return null;}
}
function requestLink(appUrl,requestId,view) {
  if (!UUID.test(String(requestId))) throw invalid('EMAIL_INVALID_REQUEST','Некорректный номер заявки.');
  let url;
  try {url=new URL(appUrl);} catch {throw invalid('EMAIL_INVALID_APP_URL','Не задан корректный адрес сервиса.');}
  const local = ['localhost','127.0.0.1','[::1]','terminal.local'].includes(url.hostname);
  if ((url.protocol!=='https:' && !(url.protocol==='http:'&&local)) || url.username || url.password) throw invalid('EMAIL_INVALID_APP_URL','Адрес сервиса должен использовать HTTPS.');
  // Do not propagate access tokens or arbitrary parameters from a base URL.
  url.pathname='/';url.search='';url.hash='';
  url.searchParams.set('view',view);url.searchParams.set('request',requestId);
  return url.toString();
}
function factsTable(facts) {
  return '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse">'+facts.map(([label,value])=>`<tr><td style="padding:9px 14px 9px 0;border-bottom:1px solid #e8e0d4;vertical-align:top;width:35%;color:#766d5e;font-size:14px">${esc(label)}</td><td style="padding:9px 0;border-bottom:1px solid #e8e0d4;vertical-align:top;font-size:15px">${paragraphs(value)}</td></tr>`).join('')+'</table>';
}
const factsText = facts => facts.map(([label,value])=>`${raw(label)}: ${raw(value)}`).join('\n');
function section(title,body) {return `<h2 style="font-family:Georgia,'Times New Roman',serif;font-size:23px;line-height:1.3;font-weight:normal;color:#263d32;margin:30px 0 14px">${esc(title)}</h2>${body}`;}
function note(message) {return `<div style="background:#eee9dc;border-left:3px solid #8b8c65;padding:14px 16px;font-size:14px;line-height:1.6;margin:18px 0">${paragraphs(message)}</div>`;}
function shell({title,subtitle,body,url,cta,accessNote='Для просмотра заявки войдите в кабинет менеджера. Ссылка не содержит данных для входа.'}) {
  return `<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title></head><body style="margin:0;padding:0;background:#f3efe6;color:#263d32;font-family:Arial,Helvetica,sans-serif;font-size:16px;line-height:1.6"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3efe6"><tr><td align="center" style="padding:28px 12px"><table role="presentation" width="640" cellpadding="0" cellspacing="0" style="width:100%;max-width:640px;background:#fffcf6;border:1px solid #e5ddcf;border-radius:14px"><tr><td style="padding:30px 30px 18px;border-bottom:1px solid #e5ddcf"><div style="letter-spacing:4px;font-family:Georgia,'Times New Roman',serif;font-size:23px">TIARE TRAVEL</div><div style="color:#81745f;font-size:12px;letter-spacing:2px;margin-top:6px">ВАШЕ ПУТЕШЕСТВИЕ В ДЕТАЛЯХ</div></td></tr><tr><td style="padding:24px 30px 32px;overflow-wrap:anywhere"><h1 style="font-family:Georgia,'Times New Roman',serif;font-size:32px;line-height:1.2;font-weight:normal;margin:0 0 14px">${esc(title)}</h1><p style="margin:0 0 20px;color:#706757">${paragraphs(subtitle)}</p>${body}<table role="presentation" cellpadding="0" cellspacing="0" style="margin-top:28px"><tr><td style="background:#2d4537;border-radius:7px"><a href="${esc(url)}" style="display:inline-block;padding:14px 22px;color:#ffffff;text-decoration:none;font-size:15px;font-weight:bold">${esc(cta)}</a></td></tr></table><p style="font-size:12px;color:#847965;margin:14px 0 0">${paragraphs(accessNote)}</p></td></tr><tr><td style="padding:20px 30px;border-top:1px solid #e5ddcf;color:#847965;font-size:12px">Tiare Travel · Индивидуальные путешествия<br>Письмо относится к вашей заявке. Бронирование выполняется менеджером после согласования.</td></tr></table></td></tr></table></body></html>`;
}
function requestFacts(request) {
  const i=request.input??{};
  return [
    ['Клиент',defined(request.customerName)],['Почта',defined(request.customerEmail)],['Связь',defined(request.contact)],
    ['Форматы',list(i.formats).map(x=>FORMAT[x]||raw(x)).join(', ')||'Открыт к предложениям'],
    ['Направление',defined(i.destination,'Открыт к предложениям')],['Исключить',defined(i.excluded,'Нет исключений')],
    ['Вылет',defined(i.departure)],['Начало поездки',day(i.date)],['Продолжительность',`${i.nights??'—'} ночей`],
    ['Участники',`${i.adults??'—'} взрослых${list(i.children).length?`; дети: ${list(i.children).join(', ')} лет`:'; без детей'}`],
    ['Бюджет на всех',currency(i.budget)],['Класс перелёта',i.cabin==='business'?'Бизнес':'Эконом'],
    ['Дорога',`${i.directOnly?'Только прямые рейсы':'Пересадки допустимы'}${Number(i.maxHours)>0?`; не более ${i.maxHours} ч`:''}`],
    ['Приоритеты',list(i.priorities).map(x=>PRIORITY[x]||raw(x)).join(', ')||'Не выбраны'],
    ['Ритм',PACE[i.pace]||'Не указан'],['Смена отелей',`Не более ${i.hotelChanges??'—'}`],
    ['Обязательные условия',defined(i.special,'Нет дополнительных условий')],['Комментарий клиента',defined(request.notes,'Нет комментария')]
  ];
}
function candidateParts(candidate,index) {
  const j=candidate?.journey??{};
  const e=candidate?.estimate;
  const cost=e&&Number.isFinite(e.low)&&Number.isFinite(e.high)&&e.low>=0&&e.high>=e.low
    ? `${currency(e.low)} — ${currency(e.high)} · ${e.kind==='estimate'?'плановый ориентир, цена и наличие не подтверждены':'ДЕМОНСТРАЦИОННЫЙ РАСЧЁТ, условные суммы'}`
    : 'Требуется индивидуальный расчёт; цена и наличие не подтверждены';
  const rows=[['Направление',list(j.destinations).join(' → ')||defined(j.country)],
    ['Отель и номер',list(j.hotel).map(h=>`${raw(h.name)} — ${raw(h.room)} (${raw(h.location)})`).join('\n')||'Требует подбора'],
    ['Бюджет',cost],['Почему подходит',defined(candidate?.rationale,list(candidate?.matches).map(x=>PRIORITY[x]||raw(x)).join(', ')||'Проверьте соответствие пожеланиям клиента')],
    ['Несоответствия',list(candidate?.issues).map(v=>raw(v)).join('\n')||'Не выявлены правилами подбора; требуется проверка менеджера'],
    ['Что проверить',list(candidate?.review).map(v=>raw(v)).join('\n')||'Даты, размещение, транспорт, состав услуг и наличие'],
    ['Особенности',defined(j.tradeoff)]];
  const heading=`${index+1}. ${defined(j.title,'Идея для рассмотрения')}`;
  return {html:section(heading,factsTable(rows)),text:`${heading}\n${factsText(rows)}`};
}

/** Build a private, manager-facing brief. Candidate facts come only from input. */
export function buildManagerRequestEmail({request,candidates=[],appUrl}) {
  if (!request||typeof request!=='object') throw invalid('EMAIL_INVALID_REQUEST','Не передана заявка.');
  const url=requestLink(appUrl,request.id,'agent');
  const facts=requestFacts(request);
  if (request.status==='agreed') {
    const title='Клиент согласовал путешествие';
    const intro='Заявка передана на оформление. Проверьте актуальность согласованных условий и выполните бронирование. При изменении стоимости или состава услуг получите новое согласование клиента.';
    const j=request.journey, q=currentQuote(request);
    const bookingFacts=[['Согласованная поездка',defined(j?.title,'Маршрут отсутствует — откройте заявку для проверки')],
      ['Начало поездки',day(q?.travelDate||request.input?.date)],['Продолжительность',`${request.input?.nights??'—'} ночей`],
      ['Отель и номер',list(j?.hotel).map(h=>`${raw(h.name)} — ${raw(h.room)} (${raw(h.location)})`).join('\n')||'Требует проверки']];
    const quoteFacts=q?[['Согласованная сумма на всех',currency(q.amount)],['Состав услуг',q.scope],['Наличие по результату проверки',q.availability],
      ['Оплата и отмена',q.terms],['Проверено менеджером',instant(q.checkedAt)],['Предложение действует до',instant(q.validUntil)]]:[];
    const notice=q?'Клиент согласовал предложение. Наличие проверено на указанное время; бронирование ещё необходимо выполнить.':
      'Клиент согласовал предложение, но подтверждение стоимости и наличия уже истекло или неполно. Повторно проверьте условия перед оформлением. В письме не приводится неактуальная сумма.';
    const comment=raw(request.managerNote);
    const body=section('К оформлению',factsTable(bookingFacts))+(q?section('Согласованные условия',factsTable(quoteFacts)):'')+note(notice)+
      (comment?section('Комментарий к предложению',`<p>${paragraphs(comment)}</p>`):'')+section('Контакты и пожелания клиента',factsTable(facts));
    return {subject:`Tiare Travel · клиент согласовал · ${oneLine(request.id.slice(0,8).toUpperCase())} · ${oneLine(request.customerName,80)||'Клиент'}`,
      html:shell({title,subtitle:intro,body,url,cta:'Открыть заявку для оформления'}),
      text:`TIARE TRAVEL\n${title}\n\n${intro}\n\nК ОФОРМЛЕНИЮ\n${factsText(bookingFacts)}${q?'\n\nСОГЛАСОВАННЫЕ УСЛОВИЯ\n'+factsText(quoteFacts):''}\n\n${notice}${comment?'\n\nКомментарий к предложению\n'+comment:''}\n\nКОНТАКТЫ И ПОЖЕЛАНИЯ КЛИЕНТА\n${factsText(facts)}\n\nОткрыть заявку для оформления (вход в кабинет менеджера): ${url}`};
  }
  const items=list(candidates).slice(0,5).map(candidateParts);
  const title='Новая заявка на путешествие';
  const intro='Подготовлены варианты для вашего рассмотрения. Выберите подходящий, измените маршрут или составьте своё предложение. Клиент получит только опубликованную вами версию.';
  const noCandidates='Готовых вариантов для этой заявки пока нет. Подготовьте индивидуальный маршрут с учётом обязательных условий клиента.';
  const body=section('Пожелания клиента',factsTable(facts))+note('Внутреннее письмо агентству. Подборка ещё не является клиентским предложением. Демонстрационные суммы нельзя использовать как подтверждённую цену.')+(items.length?items.map(x=>x.html).join(''):section('Индивидуальный подбор',`<p>${esc(noCandidates)}</p>`));
  return {subject:`Tiare Travel · заявка ${oneLine(request.id.slice(0,8).toUpperCase())} · ${oneLine(request.customerName,90)||'Новый клиент'}`,
    html:shell({title,subtitle:intro,body,url,cta:'Рассмотреть и подготовить предложение'}),
    text:`TIARE TRAVEL\n${title}\n\n${intro}\n\nВНУТРЕННЕЕ ПИСЬМО АГЕНТСТВУ. Демонстрационные суммы не подтверждают стоимость и наличие.\n\n${factsText(facts)}\n\n${items.length?items.map(x=>x.text).join('\n\n'):noCandidates}\n\nОткрыть заявку (вход в сервис): ${url}`};
}

function currentQuote(request) {
  const q=request.quote, now=Date.now();
  if (!['proposal','agreed'].includes(request.status)||!q||!Number.isFinite(q.amount)||q.amount<=0||!safePublicUrl(q.source)||
    !dateOnlyValid(q.travelDate)||!instantValid(q.checkedAt)||!instantValid(q.validUntil)||Date.parse(q.checkedAt)>now||
    Date.parse(q.validUntil)<=now||Date.parse(q.validUntil)<=Date.parse(q.checkedAt)||
    raw(q.scope).length<15||raw(q.availability).length<10||raw(q.terms).length<10) return null;
  return q;
}
function publishedJourneyParts(j) {
  const rows=[['Маршрут',list(j.destinations).map(v=>raw(v)).join(' → ')||defined(j.country)],
    ['Проживание',list(j.hotel).map(h=>`${raw(h.name)} · ${raw(h.room)}\n${raw(h.location)}. ${raw(h.description)}`).join('\n\n')],
    ['Логистика',defined(j.logistics)],['Особенности',defined(j.tradeoff)],['Сезонность',defined(j.season)],
    ['Документы',defined(j.documents)],['Предусмотрено программой',list(j.includes).map(v=>raw(v)).join('\n')],['Не включено / уточняется',list(j.excludes).map(v=>raw(v)).join('\n')]];
  const program=list(j.program).slice(0,30).map((d,i)=>`${i+1}. ${raw(d.title)}\n${raw(d.activity)}\n${raw(d.evening)}`);
  return {html:section('Ваш маршрут',`<p>${paragraphs(j.overview)}</p>${factsTable(rows)}`)+(program.length?section('Эскиз программы',program.map(p=>`<p style="margin:0 0 16px">${paragraphs(p)}</p>`).join('')):''),
    text:`${raw(j.overview)}\n\n${factsText(rows)}${program.length?'\n\nЭСКИЗ ПРОГРАММЫ\n'+program.join('\n\n'):''}`};
}

/**
 * Only an explicitly published journey may be emailed to a client. Candidate
 * lists, internalNote, supplier confirmation links and planning prices are not
 * serialized. managerNote is the explicitly client-facing comment in our model.
 */
export function buildClientProposalEmail({request,appUrl}) {
  if (!request||!['selection','pricing','proposal','agreed'].includes(request.status)||!request.journey||typeof request.journey!=='object')
    throw invalid('EMAIL_NOT_PUBLISHED','Сначала опубликуйте одобренное предложение для клиента.');
  const url=requestLink(appUrl,request.id,'requests');
  const j=request.journey, q=currentQuote(request), parts=publishedJourneyParts(j), i=request.input??{};
  const title=defined(j.title,'Ваше путешествие');
  const intro=`${defined(request.customerName,'Здравствуйте')}, менеджер подготовил для вас предложение. ${request.status==='agreed'?'Вы согласовали его; следующий шаг — оформление менеджером.':'Посмотрите маршрут и обсудите необходимые изменения с менеджером.'}`;
  const summary=[['Начало поездки',day(q?.travelDate||i.date)],['Продолжительность',`${i.nights??'—'} ночей`],['Участники',`${i.adults??'—'} взрослых${list(i.children).length?`; детей: ${list(i.children).length}`:''}`]];
  const quoteRows=q?[['Сумма на всех',currency(q.amount)],['Состав услуг',q.scope],['Наличие по результату проверки',q.availability],['Оплата и отмена',q.terms],['Проверено менеджером',instant(q.checkedAt)],['Предложение действует до',instant(q.validUntil)]]:[];
  const quoteMessage=q?'Цена и наличие проверены менеджером на указанное время. Наличие может измениться до оформления; письмо не подтверждает бронирование.':
    ['proposal','agreed'].includes(request.status)?'Сумма и наличие требуют повторного подтверждения. В письме не приводится просроченный или неполный расчёт. Обратитесь к менеджеру за актуальными условиями.':
    j.priceKind==='demo'?'Идея одобрена менеджером. В тестовой коллекции используются демонстрационные суммы; актуальная стоимость и наличие для вашей поездки пока не подтверждены.':'Идея одобрена менеджером. Плановые ориентиры коллекции не подтверждают цену: менеджер уточнит стоимость, наличие и условия для ваших дат.';
  const comment=raw(request.managerNote);
  const body=factsTable(summary)+(comment?section('Комментарий менеджера',`<p>${paragraphs(comment)}</p>`):'')+parts.html+
    (q?section('Стоимость и условия',factsTable(quoteRows)):'')+note(quoteMessage);
  return {subject:`Tiare Travel · ${request.status==='agreed'?'Согласованное путешествие':'Ваше предложение'} · ${oneLine(title,110)}`,
    html:shell({title,subtitle:intro,body,url,cta:'Открыть моё предложение',accessNote:'Откройте ссылку в том же браузере, в котором заполняли анкету: доступ к заявке сохранён в этом браузере.'}),
    text:`TIARE TRAVEL\n${title}\n\n${intro}\n\n${factsText(summary)}${comment?'\n\nКомментарий менеджера\n'+comment:''}\n\n${parts.text}${q?'\n\nСТОИМОСТЬ И УСЛОВИЯ\n'+factsText(quoteRows):''}\n\n${quoteMessage}\n\nОткрыть предложение в том же браузере, в котором заполняли анкету: ${url}`};
}

const providerNames=new Set(['invalid_idempotency_key','validation_error','missing_api_key','restricted_api_key','email_above_quota','invalid_permission','suspended_api_key','not_found','method_not_allowed','concurrent_idempotent_requests','invalid_idempotent_request','resource_locked','invalid_attachment','invalid_parameter','missing_required_field','missing_required_parameter','daily_quota_exceeded','monthly_quota_exceeded','rate_limit_exceeded','application_error','service_unavailable']);
function retryAfter(header) {
  if (!header) return null;
  const seconds=/^\d+(\.\d+)?$/.test(header.trim())?Math.ceil(Number(header)):Math.ceil((Date.parse(header)-Date.now())/1000);
  return Number.isFinite(seconds)&&seconds>=0?Math.min(seconds,31*24*3600):null;
}
function statusError(response,data,mutating) {
  const status=Number(response.status)||0;
  const name=providerNames.has(data?.name)?data.name:'provider_error';
  const quota=['daily_quota_exceeded','monthly_quota_exceeded'].includes(name);
  const concurrent=name==='concurrent_idempotent_requests';
  const retryable=!quota&&(status===408||status===429||status>=500||concurrent||name==='resource_locked');
  return new EmailProviderError('RESEND_'+name.toUpperCase(),{status,retryable,
    ambiguous:mutating&&(status===408||status>=500||concurrent),retryAfterSeconds:retryAfter(response.headers?.get?.('retry-after')),
    message:status===401||status===403?'Почтовый сервис отклонил доступ. Проверьте ключ API, права и домен отправителя.':
      quota?'Достигнут лимит почтового сервиса. Отправка приостановлена до проверки лимита.':
      status===429?'Почтовый сервис просит уменьшить частоту запросов.':
      name==='invalid_idempotent_request'?'Содержимое повторной отправки отличается от исходного. Требуется проверка очереди.':
      'Почтовый сервис отклонил запрос. Код ошибки сохранён без персональных данных.'});
}
function credential(apiKey) {
  if (typeof apiKey!=='string'||!/^re_[A-Za-z0-9_-]{3,500}$/.test(apiKey)) throw invalid('EMAIL_NOT_CONFIGURED','Не настроен ключ почтового сервиса.');
  return apiKey;
}
function address(value,displayName=false) {
  if (typeof value!=='string'||value.length>320||/[\r\n\u0000]/.test(value)) throw invalid();
  const input=value.trim();
  const bracket=displayName?input.match(/^[^<>]{1,120}\s*<([^<>]+)>$/):null;
  const mailbox=bracket?bracket[1]:input;
  if (!/^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?\.[A-Za-z]{2,63}$/.test(mailbox)||mailbox.includes('..')) throw invalid();
  return input;
}
function addresses(value) {
  const items=Array.isArray(value)?value:[value];
  if (!items.length||items.length>50) throw invalid();
  return items.map(v=>address(v));
}

async function providerRequest({apiKey,path='',method,body,idempotencyKey,fetchImpl}) {
  const token=credential(apiKey), mutating=method==='POST', controller=new AbortController();
  let timer;
  const timeout=new Promise((_,reject)=>{timer=setTimeout(()=>{controller.abort();reject(new EmailProviderError('RESEND_TIMEOUT',{retryable:true,ambiguous:mutating,message:'Почтовый сервис не ответил вовремя. Результат отправки требует проверки.'}));},RESEND_TIMEOUT_MS);});
  const operation=(async()=>{
    let response;
    try {
      response=await fetchImpl(API+path,{method,headers:{Authorization:`Bearer ${token}`,Accept:'application/json',...(body?{'Content-Type':'application/json'}:{}),...(idempotencyKey?{'Idempotency-Key':idempotencyKey}:{})},...(body?{body:JSON.stringify(body)}:{}),signal:controller.signal,redirect:'error'});
    } catch {
      throw new EmailProviderError(controller.signal.aborted?'RESEND_TIMEOUT':'RESEND_NETWORK_ERROR',{retryable:true,ambiguous:mutating,message:'Не получен ответ почтового сервиса. Проверьте результат до новой отправки.'});
    }
    let data;
    try {data=await response.json();} catch {
      if (!response.ok) throw statusError(response,null,mutating);
      throw new EmailProviderError('RESEND_INVALID_RESPONSE',{status:response.status,retryable:true,ambiguous:mutating,message:'Почтовый сервис вернул неполный ответ. Результат требует проверки.'});
    }
    if (!response.ok) throw statusError(response,data,mutating);
    if (!data||typeof data!=='object'||!UUID.test(data.id)) throw new EmailProviderError('RESEND_INVALID_RESPONSE',{status:response.status,retryable:true,ambiguous:mutating,message:'Почтовый сервис не вернул идентификатор письма. Результат требует проверки.'});
    return data;
  })();
  try {return await Promise.race([operation,timeout]);} finally {clearTimeout(timer);}
}

/** A successful POST means accepted by Resend, never delivered to an inbox. */
export async function sendResendEmail({apiKey,from,to,replyTo,subject,html,text,idempotencyKey,fetchImpl=globalThis.fetch}) {
  if (typeof fetchImpl!=='function') throw invalid();
  if (typeof idempotencyKey!=='string'||!/^[\x21-\x7e]{1,256}$/.test(idempotencyKey)) throw invalid('EMAIL_INVALID_IDEMPOTENCY_KEY','Для отправки нужен постоянный уникальный ключ очереди.');
  if (typeof subject!=='string'||!subject.trim()||subject.length>300||/[\r\n\u0000]/.test(subject)) throw invalid();
  if (typeof html!=='string'||!html.trim()||html.length>500000||typeof text!=='string'||!text.trim()||text.length>200000) throw invalid();
  const body={from:address(from,true),to:addresses(to),subject,html,text,...(replyTo?{reply_to:addresses(replyTo)}:{})};
  const data=await providerRequest({apiKey,method:'POST',body,idempotencyKey,fetchImpl});
  return {id:data.id,status:'accepted'};
}

const knownEvents=new Set(['sent','queued','scheduled','delivery_delayed','delivered','opened','clicked','bounced','complained','failed','canceled','suppressed']);
/** Only expose provider delivery metadata, never retrieved message bodies. */
export async function getResendEmail({apiKey,id,fetchImpl=globalThis.fetch}) {
  if (!UUID.test(String(id))||typeof fetchImpl!=='function') throw invalid();
  const data=await providerRequest({apiKey,path:`/${encodeURIComponent(id)}`,method:'GET',fetchImpl});
  if (data.id.toLowerCase()!==id.toLowerCase()) throw new EmailProviderError('RESEND_INVALID_RESPONSE',{retryable:true,message:'Почтовый сервис вернул другой идентификатор письма.'});
  const reportedEvent=knownEvents.has(data.last_event)?data.last_event:'unknown';
  const status=['sent','queued','scheduled','delivery_delayed'].includes(reportedEvent)?'accepted':
    ['delivered','opened','clicked'].includes(reportedEvent)?'delivered':
    ['failed','canceled','suppressed'].includes(reportedEvent)?'failed':reportedEvent;
  return {id:data.id,status,reportedEvent,...(typeof data.created_at==='string'&&Number.isFinite(Date.parse(data.created_at))?{createdAt:new Date(data.created_at).toISOString()}:{})};
}
