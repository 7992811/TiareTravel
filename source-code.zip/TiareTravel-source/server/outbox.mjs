import {randomUUID} from 'node:crypto';
import {buildManagerRequestEmail,buildClientProposalEmail,sendResendEmail,getResendEmail} from './mail.mjs';

const emailPattern=/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/;
const errorText=error=>error?.code?`Ошибка почтового сервиса: ${String(error.code).replace(/[^A-Z0-9_]/g,'').slice(0,70)}`:'Почтовый сервис временно недоступен.';
const safe=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function appUrl(env){const source=env.APP_BASE_URL||env.RENDER_EXTERNAL_URL||'http://localhost:'+String(env.PORT||3000);const url=new URL(source);if(!['http:','https:'].includes(url.protocol)||url.username||url.password)throw new Error('APP_BASE_URL должен быть адресом сервиса без учётных данных.');return url.origin;}
export function mailConfiguration(env,mode=env.MAIL_MODE||'test'){
 const missing=[];
 if(!['test','live'].includes(mode))missing.push('MAIL_MODE');
 if(!env.RESEND_API_KEY)missing.push('RESEND_API_KEY');
 if(!env.MAIL_FROM||/[\r\n]/.test(env.MAIL_FROM))missing.push('MAIL_FROM');
 if(mode==='test'&&!emailPattern.test(env.TEST_RECIPIENT_EMAIL||''))missing.push('TEST_RECIPIENT_EMAIL');
 const clientConfigured=!missing.length,managerConfigured=clientConfigured&&emailPattern.test(env.MANAGER_EMAIL||'');
 return {mode,configured:managerConfigured,missing:[...missing,...(!emailPattern.test(env.MANAGER_EMAIL||'')?['MANAGER_EMAIL']:[])],managerConfigured,clientConfigured};
}
function recordConfiguration(env,kind,mode,intendedTo){const config=mailConfiguration(env,mode);const missing=config.missing.filter(v=>kind==='manager'||v!=='MANAGER_EMAIL');if(!intendedTo&&kind==='client')missing.push('CUSTOMER_EMAIL');return {ready:!missing.length,missing};}
export function outboxRecord(row){return {id:row.id,requestId:row.request_id,requestRevision:row.request_revision,kind:row.kind,mode:row.mode,intendedTo:row.intended_to,recipient:row.recipient,from:row.sender||'',subject:row.subject,status:row.status,providerId:row.provider_id,attempts:row.attempts,lastError:row.last_error,createdAt:row.created_at,updatedAt:row.updated_at,acceptedAt:row.accepted_at,deliveredAt:row.delivered_at};}

export async function enqueueMail(tx,env,request,kind,dedupeSuffix){
 const key=`${kind}:${request.id}:${dedupeSuffix}`;
 const existing=await tx.query('SELECT * FROM email_outbox WHERE dedupe_key=?',[key]);if(existing.rows[0])return outboxRecord(existing.rows[0]);
 const mode=env.MAIL_MODE||'test',intendedTo=kind==='manager'?(env.MANAGER_EMAIL||''):request.customerEmail;
 const recipient=mode==='test'?(env.TEST_RECIPIENT_EMAIL||''):intendedTo;
 const content=kind==='manager'?buildManagerRequestEmail({request,candidates:request.candidates,appUrl:appUrl(env)}):buildClientProposalEmail({request,appUrl:appUrl(env)});
 const banner=`ТЕСТОВАЯ СРЕДА TIARE TRAVEL. Предназначено: ${intendedTo||'менеджеру (адрес не настроен)'}. Письмо направлено только на тестовый адрес.`;
 const subject=mode==='test'?`[ТЕСТ] ${content.subject}`:content.subject,html=mode==='test'?`<div style="padding:14px;background:#fff1cc;color:#423b20;font:14px Arial">${safe(banner)}</div>${content.html}`:content.html,text=mode==='test'?`${banner}\n\n${content.text}`:content.text;
 const cfg=recordConfiguration(env,kind,mode,intendedTo),id=randomUUID(),now=new Date().toISOString(),status=cfg.ready?'queued':'blocked',lastError=cfg.ready?'':`Не настроено: ${cfg.missing.join(', ')}.`;
 await tx.query('INSERT INTO email_outbox(id,dedupe_key,request_id,request_revision,kind,mode,intended_to,recipient,sender,subject,html,text_body,reply_to,status,next_attempt_at,last_error,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',[id,key,request.id,request.revision,kind,mode,intendedTo,recipient,env.MAIL_FROM||'',subject,html,text,kind==='manager'?request.customerEmail:'',status,now,lastError,now,now]);
 return {id,status};
}

export function createOutbox(db,env,providers={send:sendResendEmail,get:getResendEmail}){
 let running=false,stopped=false,timer;
 async function processOne(){
  const now=new Date().toISOString();
  const candidate=await db.query("SELECT * FROM email_outbox WHERE ((status='queued' AND next_attempt_at<=?) OR (status='sending' AND lease_until<?)) ORDER BY created_at LIMIT 1",[now,now]);
  const row=candidate.rows[0];if(!row)return false;
  const cfg=recordConfiguration(env,row.kind,row.mode,row.intended_to);
  if(!cfg.ready){await db.query("UPDATE email_outbox SET status='blocked',last_error=?,updated_at=? WHERE id=? AND status IN ('queued','sending')",[`Не настроено: ${cfg.missing.join(', ')}.`,now,row.id]);return true;}
  if(!row.sender||!row.recipient){await db.query("UPDATE email_outbox SET status='blocked',last_error=?,updated_at=? WHERE id=? AND status IN ('queued','sending')",['Не зафиксированы адреса письма. Проверьте настройки и повторите отправку.',now,row.id]);return true;}
  if(row.attempts>0&&Date.now()-Date.parse(row.created_at)>23*3600000){await db.query("UPDATE email_outbox SET status='unknown',last_error=?,updated_at=? WHERE id=? AND status IN ('queued','sending')",['Прошло окно безопасного повтора. Проверьте письмо у провайдера перед повторной отправкой.',now,row.id]);return true;}
  if(row.kind==='client'){
   const current=await db.query('SELECT revision,status,quote_json FROM travel_requests WHERE id=?',[row.request_id]);const request=current.rows[0];
   const quote=request?.quote_json?JSON.parse(request.quote_json):null;
   if(!request||request.revision!==row.request_revision||!['selection','proposal'].includes(request.status)||(request.status==='proposal'&&(!quote||Date.parse(quote.validUntil)<=Date.now()))){await db.query("UPDATE email_outbox SET status='cancelled',last_error=?,updated_at=? WHERE id=? AND status IN ('queued','sending')",['Предложение изменилось или срок цены истёк. Подготовьте письмо из актуальной заявки.',now,row.id]);return true;}
  }
  const leaseUntil=new Date(Date.now()+120000).toISOString();
  const claim=await db.query("UPDATE email_outbox SET status='sending',attempts=attempts+1,lease_until=?,updated_at=? WHERE id=? AND ((status='queued' AND next_attempt_at<=?) OR (status='sending' AND lease_until<?))",[leaseUntil,now,row.id,now,now]);
  if(claim.changes!==1)return true;
  try{
   // The queued recipient and rendered payload remain immutable for provider idempotency.
   const result=await providers.send({apiKey:env.RESEND_API_KEY,from:row.sender,to:row.recipient,replyTo:row.reply_to||undefined,subject:row.subject,html:row.html,text:row.text_body,idempotencyKey:`tiare-${row.id}`});
   if(!result?.id)throw Object.assign(new Error('Provider returned no id'),{code:'NO_PROVIDER_ID',retryable:true,ambiguous:true});
   const accepted=new Date().toISOString();await db.query("UPDATE email_outbox SET status='accepted',provider_id=?,accepted_at=?,updated_at=?,lease_until=NULL,last_error='',next_attempt_at=? WHERE id=? AND lease_until=?",[result.id,accepted,accepted,new Date(Date.now()+60000).toISOString(),row.id,leaseUntil]);
  }catch(error){
   const ambiguous=error?.ambiguous?1:0,attempts=row.attempts+1,retry=!!error?.retryable&&attempts<5;
   const delay=Math.min(15*60000,Math.max(30000,Number(error?.retryAfterSeconds||0)*1000,30000*2**(attempts-1)));
   const status=retry?'queued':ambiguous?'unknown':'failed';
   await db.query('UPDATE email_outbox SET status=?,ambiguous=?,next_attempt_at=?,lease_until=NULL,last_error=?,updated_at=? WHERE id=? AND lease_until=?',[status,ambiguous,new Date(Date.now()+delay).toISOString(),errorText(error),new Date().toISOString(),row.id,leaseUntil]);
  }return true;
 }
 async function refresh(emailId){
  const result=await db.query('SELECT * FROM email_outbox WHERE id=?',[emailId]);const row=result.rows[0];
  if(!row){const e=new Error('Письмо не найдено.');e.status=404;throw e;}
  if(!row.provider_id){const e=new Error('Провайдер ещё не подтвердил приём письма.');e.status=409;throw e;}
  if(!env.RESEND_API_KEY){const e=new Error('RESEND_API_KEY не настроен.');e.status=503;throw e;}
  try{const result=await providers.get({apiKey:env.RESEND_API_KEY,id:row.provider_id});const now=new Date().toISOString();const status=['accepted','delivered','bounced','complained','failed','unknown'].includes(result.status)?result.status:'unknown';await db.query('UPDATE email_outbox SET status=?,updated_at=?,delivered_at=?,last_error=?,next_attempt_at=? WHERE id=?',[status,now,status==='delivered'?(row.delivered_at||now):row.delivered_at,status==='unknown'?'Провайдер не сообщил однозначный статус.':'',new Date(Date.now()+300000).toISOString(),row.id]);return {status};}catch(error){await db.query('UPDATE email_outbox SET last_error=?,next_attempt_at=?,updated_at=? WHERE id=?',[errorText(error),new Date(Date.now()+300000).toISOString(),new Date().toISOString(),row.id]);const e=new Error(errorText(error));e.status=502;throw e;}
 }
 async function retry(emailId){
  return db.transaction(async tx=>{
   const {rows}=await tx.query('SELECT * FROM email_outbox WHERE id=?',[emailId]);const row=rows[0];if(!row){const e=new Error('Письмо не найдено.');e.status=404;throw e;}
   if(!['blocked','failed','unknown'].includes(row.status)||row.provider_id){const e=new Error('Это письмо уже отправлено или ожидает отправки. Повтор не требуется.');e.status=409;throw e;}
   if(row.ambiguous&&Date.now()-Date.parse(row.created_at)>23*3600000){const e=new Error('Возможно, провайдер уже принял письмо. Проверьте его журнал: безопасный срок повторной отправки истёк.');e.status=409;throw e;}
   const intended=row.intended_to||(row.kind==='manager'?env.MANAGER_EMAIL||'':''),cfg=recordConfiguration(env,row.kind,row.mode,intended),status=cfg.ready?'queued':'blocked',recipient=row.recipient||(row.mode==='test'?env.TEST_RECIPIENT_EMAIL||'':intended);
   if(row.attempts&&(!row.recipient||!row.intended_to||!row.sender)){const e=new Error('Нельзя менять адрес после попытки отправки.');e.status=409;throw e;}
   const now=new Date().toISOString();await tx.query('UPDATE email_outbox SET status=?,intended_to=?,recipient=?,sender=?,next_attempt_at=?,last_error=?,updated_at=? WHERE id=?',[status,intended,recipient,row.sender||env.MAIL_FROM||'',now,cfg.ready?'':`Не настроено: ${cfg.missing.join(', ')}.`,now,row.id]);return {status};
  });
 }
 async function drain(){if(running||stopped)return;running=true;try{for(let i=0;i<10&&!stopped;i++){if(!await processOne())break;}}catch{ /* Do not print database or provider secrets. Health and outbox retain the visible state. */ }finally{running=false;}}
 function trigger(){queueMicrotask(()=>{void drain();});}
 function start(){if(timer)return;timer=setInterval(()=>{void drain();},15000);timer.unref();trigger();}
 async function stop(){stopped=true;if(timer)clearInterval(timer);while(running)await new Promise(resolve=>setTimeout(resolve,25));}
 return {start,stop,trigger,drain,retry,refresh};
}
