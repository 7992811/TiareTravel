import {randomUUID} from 'node:crypto';
import {z} from 'zod';
import {inputSchema,journeySchema,rankJourneys,priorities,money} from '../lib/travel.ts';
import {seedJourneys} from '../lib/catalog.ts';
import {requestFromRow,saveVersion,updateStoredRequest} from './db.mjs';
import {requireManager} from './auth.mjs';
import {enqueueMail,mailConfiguration,outboxRecord} from './outbox.mjs';

const json=value=>JSON.stringify(value);
const now=()=>new Date().toISOString();
const fail=(status,message)=>{const error=new Error(message);error.status=status;throw error;};
const uuid=z.string().uuid(),revision=z.number().int().nonnegative(),https=z.string().url().refine(s=>s.startsWith('https://')&&!new URL(s).username&&!new URL(s).password);
const quoteSchema=z.object({amount:z.number().int().positive().max(100000000),source:https,travelDate:z.string(),scope:z.string().trim().min(15).max(4000),availability:z.string().trim().min(10).max(2000),terms:z.string().trim().min(10).max(4000),validUntil:z.string(),checkedAt:z.string().optional()});
const managerNote=z.string().max(4000).default('');
const actionSchema=z.discriminatedUnion('action',[
 z.object({action:z.literal('create_request'),id:uuid,input:inputSchema,journeyId:z.string().nullable().optional(),customerName:z.string().trim().min(2).max(150),customerEmail:z.string().trim().email().max(254),contact:z.string().trim().max(300).default(''),notes:z.string().max(4000).default('')}),
 z.object({action:z.literal('regenerate_candidates'),id:uuid,revision}),
 z.object({action:z.literal('save_candidate'),id:uuid,revision,candidateId:uuid,journey:journeySchema}),
 z.object({action:z.literal('publish_candidate'),id:uuid,revision,candidateId:uuid,managerNote}),
 z.object({action:z.literal('save_internal_note'),id:uuid,revision,internalNote:z.string().max(8000)}),
 z.object({action:z.literal('update_request'),id:uuid,revision,status:z.enum(['new','review','selection','pricing','proposal','agreed']),journeyId:z.string().nullable().optional(),managerNote,quote:quoteSchema.nullable().optional()}),
 z.object({action:z.literal('select_request'),id:uuid,revision}),
 z.object({action:z.literal('agree_request'),id:uuid,revision}),
 z.object({action:z.literal('send_client_email'),id:uuid,revision}),
 z.object({action:z.literal('retry_email'),emailId:uuid}),
 z.object({action:z.literal('refresh_email'),emailId:uuid}),
 z.object({action:z.literal('save_catalog'),journey:journeySchema}),
 z.object({action:z.literal('add_material'),title:z.string().trim().min(3).max(200),category:z.string().trim().min(2).max(100),sourceUrl:z.union([z.literal(''),https]).default(''),content:z.string().trim().min(10).max(16000)})
]);

export async function getCatalog(db){const {rows}=await db.query('SELECT data_json FROM travel_catalog');const stored=new Map(rows.map(row=>{const j=JSON.parse(row.data_json);return [j.id,j];}));const catalog=seedJourneys.map(j=>stored.get(j.id)||structuredClone(j));for(const [id,j]of stored)if(!seedJourneys.some(s=>s.id===id))catalog.push(j);return catalog;}
function candidateFromRank(r,id=randomUUID()){
 const matching=r.matches.map(p=>priorities[p]);
 const rationale=[matching.length?`Совпадает с интересами: ${matching.join(', ')}.`:'Альтернативная идея для обсуждения с клиентом.',r.estimate?`Расчёт ${r.estimate.kind==='demo'?'демонстрационный':'ориентировочный'}: ${money(r.estimate.low)}–${money(r.estimate.high)}.`:'Семейная стоимость требует отдельного расчёта.',r.issues.length?`До предложения клиенту устранить: ${r.issues.join('; ')}.`:'По структурированным ограничениям анкеты конфликтов не найдено.',r.review.length?`Менеджеру проверить: ${r.review.join('; ')}.`:'Цены, рейсы и наличие подтверждаются отдельно.'].join(' ');
 return {id,journey:structuredClone(r.journey),estimate:r.estimate,matches:r.matches,issues:r.issues,review:r.review,rationale};
}
export function makeCandidates(catalog,input){
 const ranked=rankJourneys(catalog,input),chosen=[],keys=new Set();
 // Different programmes in the same hotel do not consume all five recommendation slots.
 for(const r of ranked){const key=[r.journey.country,...r.journey.hotel.map(h=>h.name)].join('|');if(keys.has(key))continue;keys.add(key);chosen.push(candidateFromRank(r));if(chosen.length===5)break;}
 return chosen;
}
function validateJourney(j){if(j.minNights>j.maxNights||j.baseNights<j.minNights||j.baseNights>j.maxNights)fail(400,'Проверьте минимальную, базовую и максимальную продолжительность.');if(j.priceKind==='estimate'&&!/^https:\/\/\S+/.test(j.priceSource))fail(400,'Для рабочего бюджетного ориентира нужна ссылка на источник.');return j;}
function validateRequestDate(input){if(input.date&&input.date<new Date().toISOString().slice(0,10))fail(400,'Дата поездки уже прошла. Укажите новую дату.');}
function validatePublished(request){
 if(!request.journey)fail(409,'Сначала выберите и одобрите вариант маршрута.');
 const ranked=rankJourneys([{...request.journey,active:true}],request.input)[0];
 if(ranked.issues.length)fail(409,`Маршрут противоречит анкете: ${ranked.issues.join('; ')}. Измените вариант или оформите новую согласованную анкету.`);
 if(ranked.review.length&&request.managerNote.trim().length<20)fail(400,'Опишите клиенту, как проверены индивидуальные условия и логистика маршрута.');
 validateRequestDate(request.input);return ranked;
}
function validateQuote(quote,request){
 const parsed=quoteSchema.safeParse(quote);if(!parsed.success)fail(400,'Нужны полная стоимость, источник проверки, даты, наличие, состав услуг и условия оплаты и отмены.');
 const q=parsed.data;if(q.amount>request.input.budget)fail(400,'Подтверждённая стоимость превышает бюджет клиента. Нужна новая согласованная анкета.');
 const dateResult=inputSchema.shape.date.safeParse(q.travelDate);if(!dateResult.success||!q.travelDate||q.travelDate<new Date().toISOString().slice(0,10))fail(400,'Проверьте дату поездки.');
 if(request.input.date&&q.travelDate!==request.input.date)fail(400,'Дата предложения не совпадает с анкетой. Изменение дат оформляется новой согласованной заявкой.');
 const expiry=Date.parse(q.validUntil);if(!Number.isFinite(expiry)||expiry<=Date.now())fail(400,'Срок действия подтверждённой цены должен быть в будущем.');
 if(expiry>Date.parse(q.travelDate+'T23:59:59.999Z'))fail(400,'Срок действия цены не может быть позже даты начала поездки.');
 return {...q,validUntil:new Date(expiry).toISOString(),checkedAt:now()};
}
function currentQuote(request){if(!request.quote)fail(409,'Подтверждённое предложение ещё не готово.');const checked=Date.parse(request.quote.checkedAt);if(!Number.isFinite(checked)||checked>Date.now()+1000)fail(409,'Данные проверки цены некорректны.');validateQuote(request.quote,request);return request.quote;}
export function clientView(request){
 const {clientId,candidates,internalNote,candidateId,...publicRequest}=request;
 // An internal draft remains invisible until the manager publishes it again.
 if(!['selection','pricing','proposal','agreed'].includes(request.status)){publicRequest.journey=null;publicRequest.journeyId=null;publicRequest.quote=null;publicRequest.managerNote='';}
 if(!['proposal','agreed'].includes(request.status))publicRequest.quote=null;
 return publicRequest;
}
async function ownedRequest(tx,session,id){const {rows}=await tx.query('SELECT * FROM travel_requests WHERE id=?',[id]);if(!rows[0])fail(404,'Заявка не найдена.');const request=requestFromRow(rows[0]);if(session.role!=='manager'&&request.clientId!==session.clientId)fail(404,'Заявка не найдена.');return request;}
function assertRevision(request,expected){if(request.revision!==expected)fail(409,'Заявка уже изменена. Обновите её перед сохранением.');}

export async function readWorkspace(db,session,env){
 if(session.role!=='manager'){const {rows}=await db.query('SELECT * FROM travel_requests WHERE client_id=? ORDER BY created_at DESC LIMIT 100',[session.clientId]);return {role:'client',signedIn:true,catalog:[],requests:rows.map(requestFromRow).map(clientView),materials:[]};}
 const [catalog,requests,materials,outbox,history]=await Promise.all([getCatalog(db),db.query('SELECT * FROM travel_requests ORDER BY created_at DESC LIMIT 200'),db.query('SELECT * FROM travel_materials ORDER BY created_at DESC LIMIT 100'),db.query('SELECT * FROM email_outbox ORDER BY created_at DESC LIMIT 200'),db.query('SELECT request_id,revision,action,created_at FROM request_versions ORDER BY created_at DESC LIMIT 1000')]);
 return {role:'manager',signedIn:true,catalog,requests:requests.rows.map(requestFromRow).map(r=>({...r,history:history.rows.filter(h=>h.request_id===r.id).map(h=>({revision:h.revision,action:h.action,createdAt:h.created_at}))})),materials:materials.rows.map(r=>({id:r.id,title:r.title,category:r.category,sourceUrl:r.source_url,content:r.content,createdAt:r.created_at})),mail:{...mailConfiguration(env),testRecipientEmail:env.TEST_RECIPIENT_EMAIL||'',managerEmail:env.MANAGER_EMAIL||'',from:env.MAIL_FROM||''},outbox:outbox.rows.map(outboxRecord)};
}

export async function mutateWorkspace(db,session,env,outbox,body){
 const parsed=actionSchema.safeParse(body);if(!parsed.success)fail(400,'Проверьте заполненные поля. '+parsed.error.issues.slice(0,3).map(i=>i.path.join('.')+': '+i.message).join('; '));
 const data=parsed.data;
 if(['select_request','agree_request'].includes(data.action)&&session.role!=='client')fail(403,'Выбор и согласование выполняет клиент в своём кабинете.');
 if(!['create_request','select_request','agree_request'].includes(data.action))requireManager(session);
 if(data.action==='retry_email')return outbox.retry(data.emailId);
 if(data.action==='refresh_email')return outbox.refresh(data.emailId);
 if(data.action==='save_catalog'){const j=validateJourney({...data.journey,updatedAt:now()});await db.query('INSERT INTO travel_catalog(id,data_json,updated_at) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET data_json=excluded.data_json,updated_at=excluded.updated_at',[j.id,json(j),j.updatedAt]);return {ok:true};}
 if(data.action==='add_material'){const id=randomUUID();await db.query('INSERT INTO travel_materials(id,title,category,source_url,content,created_at) VALUES(?,?,?,?,?,?)',[id,data.title,data.category,data.sourceUrl,data.content,now()]);return {id};}
 if(data.action==='create_request'){
  validateRequestDate(data.input);
  return db.transaction(async tx=>{
   const existing=await tx.query('SELECT * FROM travel_requests WHERE id=?',[data.id]);if(existing.rows[0]){const r=requestFromRow(existing.rows[0]);if(r.clientId!==session.clientId)fail(409,'Идентификатор заявки уже используется. Начните новую заявку.');if(json(r.input)!==json(data.input)||r.customerEmail!==data.customerEmail||r.customerName!==data.customerName||r.notes!==data.notes||r.contact!==data.contact)fail(409,'Эта заявка уже сохранена с другими данными. Создайте новую заявку.');return {id:r.id,status:r.status,revision:r.revision,duplicate:true};}
   const count=await tx.query('SELECT COUNT(*) AS total FROM travel_requests WHERE client_id=? AND created_at>?',[session.clientId,new Date(Date.now()-3600000).toISOString()]);if(Number(count.rows[0].total)>=12)fail(429,'Слишком много заявок за короткое время. Повторите позже.');
   const timestamp=now(),candidates=makeCandidates(await getCatalog(tx),data.input);
   const r={id:data.id,clientId:session.clientId,input:data.input,journeyId:null,journey:null,candidateId:null,status:'review',customerName:data.customerName,customerEmail:data.customerEmail,contact:data.contact,notes:data.notes,managerNote:'',internalNote:'',candidates,quote:null,revision:0,createdAt:timestamp,updatedAt:timestamp};
   const inserted=await tx.query('INSERT INTO travel_requests(id,client_id,input_json,journey_id,journey_json,candidate_id,status,customer_name,customer_email,contact,notes,manager_note,internal_note,candidates_json,quote_json,revision,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING',[r.id,r.clientId,json(r.input),null,null,null,r.status,r.customerName,r.customerEmail,r.contact,r.notes,'','',json(candidates),null,0,timestamp,timestamp]);
   if(inserted.changes!==1)fail(409,'Заявка уже сохраняется. Обновите список заявок.');
   await saveVersion(tx,r,'create_request',session.role);const email=await enqueueMail(tx,env,r,'manager','new');return {id:r.id,status:r.status,revision:0,email};
  });
 }
 return db.transaction(async tx=>{
  const r=await ownedRequest(tx,session,data.id);assertRevision(r,data.revision);const previousRevision=r.revision;
  if(data.action==='send_client_email'){
   if(!['selection','proposal'].includes(r.status))fail(409,'Письмо клиенту можно отправить после публикации идеи или подтверждения полной стоимости.');validatePublished(r);if(r.status==='proposal')currentQuote(r);
   const email=await enqueueMail(tx,env,r,'client',`revision-${r.revision}`);return {ok:true,email};
  }
  if(data.action==='save_internal_note')r.internalNote=data.internalNote;
  else if(data.action==='regenerate_candidates'){
   if(!['review','selection'].includes(r.status))fail(409,'Верните заявку на проверку маршрута перед повторным подбором.');
   r.candidates=makeCandidates(await getCatalog(tx),r.input);
   // Existing published route remains unchanged; regenerated drafts stay private.
  }
  else if(data.action==='save_candidate'){
   const idx=r.candidates.findIndex(c=>c.id===data.candidateId);if(idx===-1)fail(404,'Вариант не найден.');
   const j=validateJourney({...data.journey,updatedAt:now()});if(!j.active)fail(400,'Вариант заявки должен быть активным.');
   r.candidates[idx]=candidateFromRank(rankJourneys([j],r.input)[0],data.candidateId);
  }
  else if(data.action==='publish_candidate'){
   if(!['review','selection'].includes(r.status))fail(409,'Верните заявку на проверку маршрута перед заменой предложения.');
   const candidate=r.candidates.find(c=>c.id===data.candidateId);if(!candidate)fail(404,'Вариант не найден.');
   r.journey=structuredClone(candidate.journey);r.journeyId=r.journey.id;r.candidateId=candidate.id;r.managerNote=data.managerNote;r.status='selection';r.quote=null;validatePublished(r);
  }
  else if(data.action==='select_request'){
   if(r.status!=='selection')fail(409,'Выбрать можно только идею, опубликованную менеджером.');validatePublished(r);r.status='pricing';r.quote=null;
  }
  else if(data.action==='agree_request'){
   if(r.status!=='proposal')fail(409,'Согласовать можно только актуальное предложение с подтверждённой стоимостью.');validatePublished(r);currentQuote(r);r.status='agreed';
  }
  else if(data.action==='update_request'){
   const transitions={new:['review'],review:['review'],selection:['selection','review'],pricing:['pricing','proposal','review'],proposal:['proposal','pricing','review'],agreed:['agreed','review']};
   if(!transitions[r.status]?.includes(data.status))fail(409,'Недопустимый переход этапа. Публикация идеи, выбор и согласование выполняются отдельными действиями.');
   if(data.journeyId!==undefined&&data.journeyId!==r.journeyId)fail(409,'Выберите маршрут из вариантов заявки и опубликуйте его отдельным действием.');
   r.managerNote=data.managerNote;
   if(data.status==='proposal'){validatePublished(r);r.quote=validateQuote(data.quote,r);}
   else if(data.status==='agreed'){if(json(data.quote)!==json(r.quote))fail(409,'Согласованное предложение нельзя менять. Верните заявку на проверку и запросите новое согласование.');}
   else if(['review','pricing','selection'].includes(data.status))r.quote=null;
   r.status=data.status;
  }
  r.revision++;r.updatedAt=now();await updateStoredRequest(tx,r,previousRevision,data.action,session.role);
  let email;if(data.action==='agree_request')email=await enqueueMail(tx,env,r,'manager',`agreed-${r.revision}`);
  return {id:r.id,status:r.status,revision:r.revision,...(email?{email}:{})};
 });
}
