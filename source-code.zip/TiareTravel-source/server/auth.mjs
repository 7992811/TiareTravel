import { randomBytes, randomUUID, createHash, timingSafeEqual } from 'node:crypto';

export const cookieName='tiare_session';
const hash=value=>createHash('sha256').update(value).digest('hex');
export const passwordVersion=env=>env.MANAGER_PASSWORD?hash('tiare-manager-v1:'+env.MANAGER_PASSWORD):'';
const day=86400000;

export function cookieValue(request){
 const found=(request.headers.cookie||'').split(';').map(part=>part.trim()).find(part=>part.startsWith(cookieName+'='));
 if(!found)return '';const token=found.slice(cookieName.length+1);return /^[A-Za-z0-9_-]{43}$/.test(token)?token:'';
}
export function setSessionCookie(response,token,env){
 const secure=!!(env.RENDER||env.NODE_ENV==='production'||(env.APP_BASE_URL||env.RENDER_EXTERNAL_URL||'').startsWith('https://'));
 response.setHeader('Set-Cookie',`${cookieName}=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${30*86400}${secure?'; Secure':''}`);
}
export async function sessionForRequest(db,request,response,env){
 const token=cookieValue(request),now=new Date().toISOString();
 if(token){const {rows}=await db.query('SELECT * FROM sessions WHERE token_hash=? AND expires_at>?',[hash(token),now]);if(rows[0]){const session=rows[0];if(session.role!=='manager'||(session.auth_version&&session.auth_version===passwordVersion(env)))return {tokenHash:session.token_hash,clientId:session.client_id,role:session.role};await db.query('DELETE FROM sessions WHERE token_hash=?',[hash(token)]);}}
 return createSession(db,response,env,'client',randomUUID());
}
export async function createSession(db,response,env,role,clientId){
 const token=randomBytes(32).toString('base64url'),now=Date.now(),tokenHash=hash(token);
 await db.query('INSERT INTO sessions(token_hash,client_id,role,auth_version,created_at,expires_at) VALUES(?,?,?,?,?,?)',[tokenHash,clientId,role,role==='manager'?passwordVersion(env):'',new Date(now).toISOString(),new Date(now+30*day).toISOString()]);
 setSessionCookie(response,token,env);return {tokenHash,clientId,role};
}
function requesterKey(request){
 // Never let user-controlled forwarding headers create unlimited independent rate-limit buckets.
 // In the test environment, several users behind one Render proxy may share a conservative bucket.
 const ip=request.socket.remoteAddress||'unknown';
 return hash('manager-login:'+ip);
}
export async function managerLogin(db,request,response,env,session,password){
 if(!env.MANAGER_PASSWORD||env.MANAGER_PASSWORD.length<16){const e=new Error('Вход менеджера пока не настроен.');e.status=503;throw e;}
 const key=requesterKey(request),now=Date.now();
 const allowed=await db.transaction(async tx=>{
  if(tx.dialect==='postgres')await tx.query('SELECT pg_advisory_xact_lock(hashtext(?))',[key]);
  const {rows}=await tx.query('SELECT * FROM auth_attempts WHERE key_hash=?',[key]);const previous=rows[0];
  if(previous&&Date.parse(previous.blocked_until)>now)return false;
  const previousCount=previous&&now-Date.parse(previous.window_at)<15*60000?previous.failures:0;
  const failures=previousCount+1,windowAt=previousCount?previous.window_at:new Date(now).toISOString(),blocked=failures>=5?new Date(now+15*60000).toISOString():'';
  await tx.query('INSERT INTO auth_attempts(key_hash,failures,window_at,blocked_until) VALUES(?,?,?,?) ON CONFLICT(key_hash) DO UPDATE SET failures=excluded.failures,window_at=excluded.window_at,blocked_until=excluded.blocked_until',[key,failures,windowAt,blocked]);return true;
 });
 if(!allowed){const e=new Error('Слишком много попыток входа. Повторите через 15 минут.');e.status=429;throw e;}
 const supplied=createHash('sha256').update(typeof password==='string'?password:'').digest(),expected=createHash('sha256').update(env.MANAGER_PASSWORD).digest();
 if(!timingSafeEqual(supplied,expected)){const e=new Error('Неверный пароль.');e.status=401;throw e;}
 await db.query('DELETE FROM auth_attempts WHERE key_hash=?',[key]);
 await db.query('DELETE FROM sessions WHERE token_hash=?',[session.tokenHash]);
 return createSession(db,response,env,'manager',session.clientId);
}
export async function managerLogout(db,response,env,session){await db.query('DELETE FROM sessions WHERE token_hash=?',[session.tokenHash]);return createSession(db,response,env,'client',session.clientId);}

export function requireManager(session){if(session.role!=='manager'){const e=new Error('Это действие доступно только менеджеру.');e.status=403;throw e;}}
