import PDFDocument from 'pdfkit';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

// The renderer is deliberately offline. All fonts, illustration and geography
// are part of the release; URLs in the model become PDF links only.
const PALETTE={ivory:'#F5F1E7',paper:'#FCFAF5',sand:'#E4DAC7',taupe:'#84796A',olive:'#414A32',ink:'#282D24',muted:'#706D61',gold:'#B39965',line:'#D8D0BF',light:'#EBE7DC',white:'#FFFFFF',warning:'#785B33'};
const PAGE={width:841.89,height:595.28,margin:42,bottom:540};
const BODY_WIDTH=PAGE.width-PAGE.margin*2;
const MAX_PAGES=180;
const MAX_BYTES=12*1024*1024;
const assetCache=new Map();
const safeText=value=>String(value??'').replace(/\r\n?/g,'\n').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g,'').replace(/[\u00A0\u202F]/g,' ').replace(/[\u2010-\u2015\u2212]/g,'-');
const canonical=value=>safeText(value).trim().toLocaleLowerCase('ru-RU').replaceAll('ё','е');
const rubles=value=>Number.isFinite(Number(value))?`${new Intl.NumberFormat('ru-RU',{maximumFractionDigits:0}).format(Number(value)).replace(/[\u00A0\u202F]/g,' ')} ₽`:'Не указана';
const displayDate=value=>{
 if(!value)return 'Дата уточняется';
 const parsed=new Date(value);
 return Number.isNaN(parsed.getTime())?safeText(value):new Intl.DateTimeFormat('ru-RU',{day:'2-digit',month:'long',year:'numeric',timeZone:'UTC'}).format(parsed);
};
const displayDateTime=value=>{
 const parsed=new Date(value);
 return Number.isNaN(parsed.getTime())?safeText(value):`${new Intl.DateTimeFormat('ru-RU',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit',timeZone:'UTC'}).format(parsed)} UTC`;
};
const httpsUrl=value=>{try{const url=new URL(value);return url.protocol==='https:'&&!url.username&&!url.password?url.href:null;}catch{return null;}};
const sourceHost=value=>{try{return new URL(value).hostname.replace(/^www\./,'');}catch{return 'Открыть источник';}};
const formatNames={beach:'Острова и море',city:'Города и культура',multi:'Несколько мест',safari:'Сафари и природа',cruise:'Круизы и экспедиции'};
const priorityNames={quiet:'Тишина и приватность',food:'Гастрономия',culture:'Культура',nature:'Природа',comfort:'Комфорт',activity:'Новые впечатления'};
const paceNames={calm:'Спокойный',balanced:'Сбалансированный',active:'Активный'};

async function assetsAt(root){
 const key=resolve(root);
 if(!assetCache.has(key))assetCache.set(key,Promise.all([
  readFile(resolve(key,'tiare-pdf-title.ttf')),
  readFile(resolve(key,'tiare-pdf-title-italic.ttf')),
  readFile(resolve(key,'tiare-pdf-body.ttf')),
  readFile(resolve(key,'tiare-pdf-cover.jpg')),
  readFile(resolve(key,'pdf-geography.json'),'utf8'),
 ]).then(([title,italic,body,cover,geography])=>({title,italic,body,cover,geography:JSON.parse(geography)})).catch(error=>{assetCache.delete(key);throw error;}));
 return assetCache.get(key);
}

function flower(doc,x,y,r,{opacity=1,fill=PALETTE.paper,stroke=PALETTE.olive}={}){
 doc.save().opacity(opacity).translate(x,y);
 for(let i=0;i<7;i++){
  doc.save().rotate(i*360/7);
  doc.moveTo(0,0).bezierCurveTo(-r*.24,-r*.18,-r*.48,-r*.69,-r*.12,-r*.96)
   .bezierCurveTo(r*.22,-r*1.08,r*.47,-r*.59,r*.15,-r*.17).bezierCurveTo(r*.09,-r*.07,r*.03,0,0,0)
   .fillAndStroke(fill,stroke).restore();
 }
 doc.circle(0,0,r*.105).fill(PALETTE.gold).restore();
}

function makeLayout(doc,model){
 const pages=[];
 let current=null;
 const setFont=(font='body',size=11)=>doc.font(font).fontSize(size);
 const widthOf=(text,font='body',size=11)=>{setFont(font,size);return doc.widthOfString(safeText(text));};
 function wrap(value,width,font='body',size=11){
  const paragraphs=safeText(value).split('\n');
  const output=[];
  setFont(font,size);
  for(const paragraph of paragraphs){
   const words=paragraph.trim().split(/\s+/).filter(Boolean);
   if(!words.length){output.push('');continue;}
   let line='';
   for(const word of words){
    const candidate=line?`${line} ${word}`:word;
    if(doc.widthOfString(candidate)<=width){line=candidate;continue;}
    if(line){output.push(line);line='';}
    if(doc.widthOfString(word)<=width){line=word;continue;}
    // User-edited links and unbroken words must also stay inside the page.
    for(const character of Array.from(word)){
     if(line&&doc.widthOfString(line+character)>width){output.push(line);line='';}
     line+=character;
    }
   }
   if(line)output.push(line);
  }
  return output.length?output:[''];
 }
 function text(value,x,y,{font='body',size=11,color=PALETTE.ink,width=BODY_WIDTH,align='left',link}={}){
  setFont(font,size);doc.fillColor(color);
  const options={lineBreak:false,align,width};
  const safeLink=httpsUrl(link);if(safeLink)options.link=safeLink;
  doc.text(safeText(value),x,y,options);
 }
 function wrapped(value,x,y,width,{font='body',size=11,color=PALETTE.ink,leading=size*1.45,link}={}){
  const lines=wrap(value,width,font,size);
  for(const line of lines){text(line,x,y,{font,size,color,width,link});y+=leading;}
  return y;
 }
 function base({cover=false,final=false}={}){
  if(pages.length>=MAX_PAGES)throw Object.assign(new Error('Предложение превышает 180 страниц. Сократите повторяющиеся описания перед экспортом.'),{status:413});
  doc.addPage({size:[PAGE.width,PAGE.height],margin:0});
  doc.rect(0,0,PAGE.width,PAGE.height).fill(final?'#F0EEE4':PALETTE.ivory);
  pages.push({cover,final});
  if(!cover){
   flower(doc,53,39,13,{fill:PALETTE.paper});
   text('Tiare Travel',75,25,{font:'title',size:24,color:PALETTE.olive});
   const marker=model.mode==='review'?'РАБОЧАЯ ВЕРСИЯ · ДЛЯ ПРОВЕРКИ':'PRIVATE JOURNEY';
   text(marker,492,33,{size:8.2,color:model.mode==='review'?PALETTE.warning:PALETTE.muted,width:308,align:'right'});
   doc.moveTo(PAGE.margin,68).lineTo(PAGE.width-PAGE.margin,68).lineWidth(.6).stroke(PALETTE.line);
  }
 }
 function page(title,{subtitle='',continued=false,section=title}={}){
  base();
  current={title,subtitle,section,y:87,continued};
  const heading=continued?`${title} · продолжение`:title;
  current.y=wrapped(heading,PAGE.margin,current.y,BODY_WIDTH,{font:'title',size:29,color:PALETTE.olive,leading:33})+7;
  if(subtitle&&!continued)current.y=wrapped(subtitle,PAGE.margin,current.y,BODY_WIDTH,{size:9.5,color:PALETTE.muted,leading:14})+14;
  else current.y+=8;
  return current;
 }
 function next(){const previous=current;page(previous.title,{section:previous.section,continued:true});}
 function ensure(height){if(!current)throw new Error('PDF layout has no current page.');if(current.y+height>PAGE.bottom)next();}
 function gap(height=12){ensure(height);current.y+=height;}
 function paragraph(value,{label,font='body',size=11,color=PALETTE.ink,leading=size*1.48,after=14,link}={}){
  if(label){ensure(36);text(label,PAGE.margin,current.y,{font:'body',size:9,color:PALETTE.muted});current.y+=18;}
  const lines=wrap(value,BODY_WIDTH,font,size);
  for(const line of lines){ensure(leading+2);text(line,PAGE.margin,current.y,{font,size,color,link});current.y+=leading;}
  current.y+=after;
 }
 function label(value){ensure(32);text(value,PAGE.margin,current.y,{font:'title',size:20,color:PALETTE.olive});current.y+=30;}
 function unitsForCard({eyebrow,title,titleSize=22,sections=[],footer},width){
  const units=[];
  const add=(value,{font='body',size=10.5,color=PALETTE.ink,leading=size*1.43,after=7,link}={})=>{
   if(value===undefined||value===null||value==='')return;
   const lines=wrap(value,width,font,size);
   for(let i=0;i<lines.length;i++)units.push({text:lines[i],font,size,color,leading,link,last:i===lines.length-1,space:i===lines.length-1?after:0});
  };
  add(eyebrow,{size:8.5,color:PALETTE.muted,leading:12,after:6});
  add(title,{font:'title',size:titleSize,color:PALETTE.olive,leading:titleSize*1.15,after:10});
  for(const section of sections){
   if(section.label)add(section.label,{size:8.5,color:PALETTE.muted,leading:12,after:4});
   add(section.text,{font:section.font??'body',size:section.size??10.5,color:section.color??PALETTE.ink,link:section.link,after:section.after??9});
  }
  add(footer,{size:8.5,color:PALETTE.muted,leading:12,after:0});
  return units;
 }
 function card(config,{accent=PALETTE.gold}={}){
  const inset=19;
  const units=unitsForCard(config,BODY_WIDTH-inset*2-4);
  const fullHeight=27+units.reduce((sum,unit)=>sum+unit.leading+unit.space,0);
  const freshStart=87+wrap(`${current.title} · продолжение`,BODY_WIDTH,'title',29).length*33+15;
  if(fullHeight<=PAGE.bottom-freshStart&&current.y+fullHeight>PAGE.bottom)next();
  let index=0,part=0;
  while(index<units.length){
   const continuation=part>0;
   const topPadding=continuation?31:17;
   ensure(topPadding+Math.min(3,units.length-index)*16+17);
   let available=PAGE.bottom-current.y-topPadding-14;
   let count=0,height=0;
   while(index+count<units.length){
    const unit=units[index+count],unitHeight=unit.leading+unit.space;
    if(height+unitHeight>available&&count)break;
    if(height+unitHeight>available&&!count){next();available=PAGE.bottom-current.y-topPadding-14;continue;}
    height+=unitHeight;count++;
   }
   if(!count)throw new Error('PDF card cannot fit a text line.');
   const tail=units.length-index-count;
   if(tail>0&&tail<4&&count>5){
    const move=4-tail;
    for(let i=0;i<move;i++){const unit=units[index+count-1];height-=unit.leading+unit.space;count--;}
   }
   const boxHeight=topPadding+height+10;
   doc.roundedRect(PAGE.margin,current.y,BODY_WIDTH,boxHeight,3).fill(PALETTE.paper);
   doc.rect(PAGE.margin,current.y,2,boxHeight).fill(accent);
   let y=current.y+17;
   if(continuation){text('ПРОДОЛЖЕНИЕ',PAGE.margin+inset+4,y-2,{size:7.5,color:PALETTE.taupe});y+=14;}
   for(let i=0;i<count;i++){
    const unit=units[index+i];
    text(unit.text,PAGE.margin+inset+4,y,{font:unit.font,size:unit.size,color:unit.color,width:BODY_WIDTH-inset*2-4,link:unit.link});
    y+=unit.leading+unit.space;
   }
   current.y+=boxHeight+12;index+=count;part++;
   if(index<units.length)next();
  }
 }
 function cardGrid(configs,{columns=2,accent=PALETTE.gold}={}){
  if(configs.length===1){card(configs[0],{accent});return;}
  const gutter=14,width=(BODY_WIDTH-gutter*(columns-1))/columns,inset=17;
  const grouped=configs.map(config=>unitsForCard(config,width-inset*2));
  const height=Math.max(...grouped.map(units=>27+units.reduce((sum,unit)=>sum+unit.leading+unit.space,0)));
  const freshStart=87+wrap(`${current.title} · продолжение`,BODY_WIDTH,'title',29).length*33+15;
  if(height>PAGE.bottom-freshStart){for(const config of configs)card(config,{accent});return;}
  ensure(height+1);
  const top=current.y;
  for(let column=0;column<grouped.length;column++){
   const x=PAGE.margin+column*(width+gutter);
   doc.roundedRect(x,top,width,height,3).fill(PALETTE.paper);
   doc.rect(x,top,2,height).fill(accent);
   let y=top+17;
   for(const unit of grouped[column]){
    text(unit.text,x+inset,y,{font:unit.font,size:unit.size,color:unit.color,width:width-inset*2,link:unit.link});
    y+=unit.leading+unit.space;
   }
  }
  current.y=top+height+12;
 }
 function factGrid(items){
  const gutter=26,width=(BODY_WIDTH-gutter)/2;
  for(let index=0;index<items.length;index+=2){
   const pair=items.slice(index,index+2).map(([name,value])=>({name,lines:wrap(value,width,'body',10.5)}));
   const height=13+Math.max(...pair.map(item=>item.lines.length))*15.5+11;
   if(height>250){for(const item of items.slice(index,index+2))paragraph(item[1],{label:item[0]});continue;}
   ensure(height);
   for(let column=0;column<pair.length;column++){
    const x=PAGE.margin+column*(width+gutter),item=pair[column];
    text(item.name,x,current.y,{size:8.5,color:PALETTE.muted,width});
    let y=current.y+13;
    for(const line of item.lines){text(line,x,y,{size:10.5,color:PALETTE.ink,width});y+=15.5;}
    doc.moveTo(x,current.y+height-5).lineTo(x+width,current.y+height-5).lineWidth(.45).stroke(PALETTE.line);
   }
   current.y+=height;
  }
  current.y+=9;
 }
 function rows(items,{valueColor=PALETTE.ink,labelWidth=195}={}){
  for(const [name,value] of items){
   const nameLines=wrap(name,labelWidth,'body',9.5),valueLines=wrap(value,BODY_WIDTH-labelWidth-24,'body',10.5);
   const lines=Math.max(nameLines.length,valueLines.length),height=lines*15.5+17;
   if(height>250){
    paragraph(value,{label:name,after:12});continue;
   }
   ensure(height);
   for(let i=0;i<nameLines.length;i++)text(nameLines[i],PAGE.margin,current.y+i*15.5,{size:9.5,color:PALETTE.muted,width:labelWidth});
   for(let i=0;i<valueLines.length;i++)text(valueLines[i],PAGE.margin+labelWidth+24,current.y+i*15.5,{size:10.5,color:valueColor,width:BODY_WIDTH-labelWidth-24});
   current.y+=height;
   doc.moveTo(PAGE.margin,current.y-6).lineTo(PAGE.width-PAGE.margin,current.y-6).lineWidth(.45).stroke(PALETTE.line);
  }
  current.y+=9;
 }
 function bullets(items,{color=PALETTE.ink}={}){
  for(const value of items??[]){
   const lines=wrap(value,BODY_WIDTH-22,'body',10.5);
   let first=true;
   for(const line of lines){
    ensure(17);
    if(first){doc.circle(PAGE.margin+3,current.y+6,1.7).fill(PALETTE.gold);first=false;}
    text(line,PAGE.margin+16,current.y,{size:10.5,color,width:BODY_WIDTH-22});current.y+=15.5;
   }
   current.y+=9;
  }
 }
 function footers(){
  const count=pages.length;
  for(let i=0;i<count;i++){
   doc.switchToPage(i);
   const {cover}=pages[i],color=cover?PALETTE.taupe:PALETTE.muted;
   if(!cover)doc.moveTo(PAGE.margin,557).lineTo(PAGE.width-PAGE.margin,557).lineWidth(.5).stroke(PALETTE.line);
   const ref=safeText(model.id).slice(0,8).toUpperCase();
   text(`TIARE TRAVEL · ЗАЯВКА ${ref} · ВЕРСИЯ ${model.revision}`,PAGE.margin,571,{size:7.2,color,width:590});
   text(`${String(i+1).padStart(2,'0')} / ${String(count).padStart(2,'0')}`,PAGE.width-104,570,{size:8,color,width:62,align:'right'});
  }
 }
 return {doc,model,pages,base,page,next,ensure,gap,paragraph,label,card,cardGrid,factGrid,rows,bullets,footers,wrap,text,wrapped,widthOf,get y(){return current?.y??0;},set y(value){current.y=value;}};
}

function coverPage(layout,assets){
 const {doc,model}=layout,j=model.journey,input=model.input;
 layout.base({cover:true});
 doc.save().rect(402,0,PAGE.width-402,PAGE.height).clip().image(assets.cover,402,0,{cover:[PAGE.width-402,PAGE.height],align:'center',valign:'center'}).restore();
 doc.rect(0,0,408,PAGE.height).fill(PALETTE.ivory);
 doc.rect(399,0,9,PAGE.height).fill(PALETTE.sand);
 flower(doc,56,49,19,{fill:PALETTE.paper});
 layout.text('Tiare',88,24,{font:'title',size:33,color:PALETTE.olive});
 layout.text('TRAVEL',89,57,{size:7.4,color:PALETTE.muted});
 doc.moveTo(42,105).lineTo(361,105).lineWidth(.65).stroke(PALETTE.line);
 const status=model.mode==='review'?'РАБОЧАЯ ВЕРСИЯ ДЛЯ МЕНЕДЖЕРА':model.quote?'ИНДИВИДУАЛЬНОЕ ПРЕДЛОЖЕНИЕ':'ИДЕЯ ВАШЕГО ПУТЕШЕСТВИЯ';
 layout.wrapped(status,42,126,320,{size:8.7,color:model.mode==='review'?PALETTE.warning:PALETTE.muted,leading:13});
 let titleSize=43,titleLines=layout.wrap(j.title,321,'title',titleSize);
 while(titleLines.length*titleSize*1.04>163&&titleSize>12){titleSize-=.5;titleLines=layout.wrap(j.title,321,'title',titleSize);}
 let y=180;
 for(const line of titleLines){layout.text(line,42,y,{font:'title',size:titleSize,color:PALETTE.olive,width:321});y+=titleSize*1.04;}
 y+=18;
 let subSize=19,subtitleLines=layout.wrap(j.subtitle,318,'italic',subSize);
 while(subtitleLines.length*subSize*1.15>468-y&&subSize>9){subSize-=.5;subtitleLines=layout.wrap(j.subtitle,318,'italic',subSize);}
 for(const line of subtitleLines){layout.text(line,43,y,{font:'italic',size:subSize,color:PALETTE.taupe,width:318});y+=subSize*1.15;}
 doc.moveTo(42,489).lineTo(116,489).lineWidth(1).stroke(PALETTE.gold);
 const effectiveDate=model.quote?.travelDate||input.date;
 layout.text(effectiveDate?displayDate(effectiveDate):'Даты подберём вместе',42,507,{size:10.5,color:PALETTE.olive,width:321});
 const party=`${input.adults} взр.${input.children?.length?` · ${input.children.length} дет.`:''} · ${input.nights} ночей по заявке`;
 layout.text(party,42,526,{size:9.2,color:PALETTE.muted,width:321});
 doc.save().opacity(.87).rect(426,523,389,31).fill(PALETTE.ivory).restore();
 layout.text('Иллюстрация настроения путешествия',442,533,{size:8.2,color:PALETTE.olive,width:357});
}

function overviewPages(layout){
 const {model}=layout,j=model.journey,input=model.input;
 layout.page('Замысел путешествия',{subtitle:formatNames[j.format]??'Индивидуальный маршрут'});
 layout.paragraph(j.overview,{font:'title',size:21,leading:27,color:PALETTE.olive,after:18});
 const effectiveDate=model.quote?.travelDate||input.date;
 const facts=[
  ['Для кого',model.customerName||'Гостей Tiare Travel'],
  ['Направление и точки маршрута',`${j.country} · ${(j.destinations??[]).join(' · ')}`],
  [model.quote?'Дата поездки / длительность':'Выезд / длительность по заявке',`${effectiveDate?displayDate(effectiveDate):'Дата подбирается с менеджером'} · ${input.nights} ночей по заявке`],
  ['Состав путешественников',`${input.adults} взрослых${input.children?.length?`; дети: ${input.children.map(age=>`${age} лет`).join(', ')}`:'; без детей'}`],
  ['Ритм и приоритеты',`${paceNames[input.pace]??input.pace}. ${(input.priorities??[]).map(p=>priorityNames[p]??p).join(', ')||'Уточняются'}`],
 ];
 if(model.mode==='review')facts.push(['Бюджет из заявки',rubles(input.budget)]);
 layout.factGrid(facts);
 layout.card({eyebrow:'ОСОБЕННОСТЬ ВАРИАНТА',sections:[{text:j.tradeoff}]});
 if(model.managerNote?.trim())layout.card({eyebrow:'КОММЕНТАРИЙ ВАШЕГО МЕНЕДЖЕРА',sections:[{text:model.managerNote}]},{accent:PALETTE.olive});
 if(input.special?.trim())layout.paragraph(input.special,{label:'Индивидуальные пожелания из заявки'});
}

function programPages(layout){
 const j=layout.model.journey;
 layout.page('Программа и впечатления',{subtitle:'Содержание выбранного варианта. Распределение этапов по датам и часам согласуется с менеджером.'});
 // Use every saved program item. Expanding a template to the requested number
 // of nights could otherwise silently drop edited days or imply a fixed date.
 const cards=[];
 for(let i=0;i<(j.program??[]).length;i++){
  const day=j.program[i],sections=[{text:`Днём. ${day.activity}`},{text:`Вечером. ${day.evening}`}];
  for(const source of day.sources??[])sections.push({text:`${source.title} · ${sourceHost(source.url)}`,size:9,color:PALETTE.olive,link:source.url,after:5});
  cards.push({eyebrow:`ЭТАП ${String(i+1).padStart(2,'0')}`,title:day.title,titleSize:20,sections});
 }
 const columns=cards.length===3?3:2;
 for(let index=0;index<cards.length;index+=columns)layout.cardGrid(cards.slice(index,index+columns),{columns});
}

function hotelPages(layout){
 const j=layout.model.journey;
 layout.page('Отели и пространство отдыха',{subtitle:'Конкретные объекты и категории размещения из выбранного варианта. Наличие на даты проверяется до оформления.'});
 for(let i=0;i<(j.hotel??[]).length;i++){
  const hotel=j.hotel[i];
  layout.card({eyebrow:`${String(i+1).padStart(2,'0')} · ${hotel.location}`,title:hotel.name,sections:[
   {label:'КАТЕГОРИЯ НОМЕРА / ВИЛЛЫ / КАЮТЫ',text:hotel.room,color:PALETTE.olive},
   {label:'ДЕТАЛИ РАЗМЕЩЕНИЯ',text:hotel.description},
   {text:`Официальный источник · ${sourceHost(hotel.url)}`,link:hotel.url,size:9,color:PALETTE.olive},
  ]});
 }
}

function logisticsPages(layout){
 const {model}=layout,input=model.input;
 layout.page('Дорога и билеты',{subtitle:'Логистика маршрута и требования к перелётам'});
 layout.paragraph(model.journey.logistics,{font:'title',size:21,leading:28,color:PALETTE.olive,after:24});
 layout.rows([
  ['Отправление из',input.departure||'Город уточняется'],
  [model.quote?'Дата поездки в расчёте':'Запрошенная дата выезда',(model.quote?.travelDate||input.date)?displayDate(model.quote?.travelDate||input.date):'Дата уточняется'],
  ['Класс перелёта',input.cabin==='business'?'Бизнес-класс':'Экономический класс'],
  ['Пересадки',input.directOnly?'По заявке нужны прямые рейсы':'Допускаются по согласованию'],
  ['Ограничение дороги',input.maxHours>0?`По заявке: не более ${input.maxHours} ч. Требует проверки на конкретных рейсах.`:'Отдельный лимит времени в заявке не задан'],
  ['Смены размещения',`В выбранном варианте: ${model.journey.changes??0}. Допустимо по заявке: ${input.hotelChanges??0}.`],
 ]);
 layout.card({eyebrow:'ЧТО ПОДТВЕРЖДАЕТСЯ ДО ОФОРМЛЕНИЯ',sections:[{text:'Конкретные рейсы, аэропорты, время вылета и прилёта, багаж, тарифные правила и условия трансферов. В сохранённом варианте нет отдельной проверенной таблицы билетов.'}]});
}

function mapPages(layout,geography){
 const {doc,model}=layout;
 const destinations=model.journey.destinations??[];
 const dictionary=geography?.locations??{};
 const points=destinations.map((name,index)=>{
  const place=dictionary[canonical(name)];
  return {name,index,place:place&&Number.isFinite(place.lon)&&Number.isFinite(place.lat)&&Math.abs(place.lat)<=90&&Math.abs(place.lon)<=180?place:null};
 });
 const known=points.filter(point=>point.place);
 layout.page('География путешествия',{subtitle:'Ориентиры выбранного маршрута'});
 const legendWidth=231,legendX=PAGE.margin+BODY_WIDTH-legendWidth;
 const sideLegend=points.map(point=>{
  const title=`${String(point.index+1).padStart(2,'0')} · ${point.name}`;
  const status=point.place?'Ориентир нанесён на карту.':'Географическая точка уточняется.';
  const source=point.place?.source?`Источник · ${sourceHost(point.place.source)}`:null;
  const titleLines=layout.wrap(title,legendWidth,'title',16),statusLines=layout.wrap(status,legendWidth,'body',10.5),sourceLines=source?layout.wrap(source,legendWidth,'body',8.5):[];
  return {point,titleLines,statusLines,sourceLines,height:titleLines.length*19+4+statusLines.length*15+3+sourceLines.length*12+9};
 });
 const useSidebar=points.length<=5&&sideLegend.reduce((sum,item)=>sum+item.height,0)<=320;
 const box={x:PAGE.margin,y:layout.y+2,w:useSidebar?BODY_WIDTH-legendWidth-25:BODY_WIDTH,h:320};
 doc.roundedRect(box.x,box.y,box.w,box.h,3).fill('#E8E9DE');
 let west=-180,east=180,south=-63,north=85;
 if(known.length){
  const lons=known.map(point=>point.place.lon),lats=known.map(point=>point.place.lat);
  west=Math.min(...lons);east=Math.max(...lons);south=Math.min(...lats);north=Math.max(...lats);
  const centerLat=(south+north)/2;
  const lonSpread=Math.max(east-west,5),latSpread=Math.max(north-south,4);
  const padLon=Math.max(lonSpread*.16,1),padLat=Math.max(latSpread*.19,1);
  west-=padLon;east+=padLon;south-=padLat;north+=padLat;
  // Equirectangular latitude correction keeps nearby maps proportionate while
  // preserving a simple, bounded projection for global routes.
  const aspect=box.w/box.h,cos=Math.max(.35,Math.cos(centerLat*Math.PI/180));
  const actual=(east-west)*cos/(north-south);
  if(actual<aspect){const desired=(north-south)*aspect/cos,mid=(east+west)/2;west=mid-desired/2;east=mid+desired/2;}
  else{const desired=(east-west)*cos/aspect,mid=(north+south)/2;south=mid-desired/2;north=mid+desired/2;}
  west=Math.max(-180,west);east=Math.min(180,east);south=Math.max(-85,south);north=Math.min(89,north);
 }
 const project=([lon,lat])=>[box.x+(lon-west)/(east-west)*box.w,box.y+box.h-(lat-south)/(north-south)*box.h];
 const polygons=[];
 for(const feature of geography?.land?.features??[]){
  if(feature.geometry?.type==='Polygon')polygons.push(feature.geometry.coordinates);
  else if(feature.geometry?.type==='MultiPolygon')polygons.push(...feature.geometry.coordinates);
 }
 doc.save().rect(box.x,box.y,box.w,box.h).clip();
 for(const polygon of polygons){
  let drew=false;
  for(const ring of polygon){
   if(!ring.length)continue;
   const allOutside=ring.every(point=>point[0]<west)||ring.every(point=>point[0]>east)||ring.every(point=>point[1]<south)||ring.every(point=>point[1]>north);
   if(allOutside)continue;
   let first=true;
   for(const coordinate of ring){
    const [x,y]=project(coordinate);if(first){doc.moveTo(x,y);first=false;}else doc.lineTo(x,y);
   }
   doc.closePath();drew=true;
  }
  if(drew)doc.lineWidth(.45).fillAndStroke('#D1D6C1','#A5AD93','even-odd');
 }
 // Only adjacent, located stages may be connected. Unknown intermediates
 // deliberately interrupt the line instead of implying a different route.
 doc.lineWidth(1.4).strokeColor(PALETTE.gold).dash(5,{space:4});
 for(let i=1;i<points.length;i++){
  if(!points[i-1].place||!points[i].place)continue;
  const [x1,y1]=project([points[i-1].place.lon,points[i-1].place.lat]);
  const [x2,y2]=project([points[i].place.lon,points[i].place.lat]);
  doc.moveTo(x1,y1).lineTo(x2,y2).stroke();
 }
 doc.undash();
 const labels=[];
 for(const point of known){
  const [px,py]=project([point.place.lon,point.place.lat]);
  const marker=String(point.index+1).padStart(2,'0'),markerW=25,markerH=21;
  const candidates=[[10,-27],[10,7],[-35,-27],[-35,7],[12,-52],[-36,32],[40,-8],[-66,-8]];
  let label=null;
  const collides=candidate=>labels.some(other=>candidate.x<other.x+other.w+3&&candidate.x+candidate.w+3>other.x&&candidate.y<other.y+other.h+3&&candidate.y+candidate.h+3>other.y);
  for(const [dx,dy] of candidates){
   const candidate={x:Math.max(box.x+5,Math.min(box.x+box.w-markerW-5,px+dx)),y:Math.max(box.y+5,Math.min(box.y+box.h-markerH-5,py+dy)),w:markerW,h:markerH};
   if(!collides(candidate)){label=candidate;break;}
  }
  if(!label){
   // Duplicate destinations and close aliases may share one coordinate. Pick
   // the nearest free slot rather than letting their numbered labels overlap.
   let bestDistance=Infinity;
   for(let y=box.y+6;y+markerH<box.y+box.h-5;y+=markerH+6){
    for(let x=box.x+6;x+markerW<box.x+box.w-5;x+=markerW+6){
     const candidate={x,y,w:markerW,h:markerH};
     if(collides(candidate))continue;
     const distance=(x+markerW/2-px)**2+(y+markerH/2-py)**2;
     if(distance<bestDistance){label=candidate;bestDistance=distance;}
    }
   }
  }
  if(!label)throw new Error('PDF map has no free label position.');
  labels.push(label);
  doc.moveTo(px,py).lineTo(label.x+markerW/2,label.y+markerH/2).lineWidth(.6).stroke(PALETTE.olive);
  doc.circle(px,py,4).fill(PALETTE.olive);doc.circle(px,py,1.6).fill(PALETTE.paper);
  doc.roundedRect(label.x,label.y,markerW,markerH,3).fill(PALETTE.olive);
  layout.text(marker,label.x+4,label.y+5,{size:8.5,color:PALETTE.paper,width:markerW-8,align:'center'});
 }
 doc.restore();
 if(!known.length){
  const inset=useSidebar?31:90,panelWidth=box.w-inset*2;
  doc.save().opacity(.94).roundedRect(box.x+inset,box.y+83,panelWidth,151,3).fill(PALETTE.paper).restore();
  let noteY=layout.wrapped('Географические точки уточняются',box.x+inset+18,box.y+106,panelWidth-36,{font:'title',size:22,color:PALETTE.olive,leading:25});
  layout.wrapped('На карте показан общий географический контекст.',box.x+inset+18,noteY+12,panelWidth-36,{size:10.5,color:PALETTE.muted,leading:15});
 }
 if(useSidebar){
  let legendY=box.y+3;
  for(const item of sideLegend){
   for(const line of item.titleLines){layout.text(line,legendX,legendY,{font:'title',size:16,color:PALETTE.olive,width:legendWidth});legendY+=19;}
   legendY+=4;
   for(const line of item.statusLines){layout.text(line,legendX,legendY,{size:10.5,color:PALETTE.muted,width:legendWidth});legendY+=15;}
   legendY+=3;
   for(const line of item.sourceLines){layout.text(line,legendX,legendY,{size:8.5,color:PALETTE.olive,width:legendWidth,link:item.point.place?.source});legendY+=12;}
   legendY+=9;
   doc.moveTo(legendX,legendY-4).lineTo(legendX+legendWidth,legendY-4).lineWidth(.45).stroke(PALETTE.line);
  }
 }
 layout.y=box.y+box.h+14;
 layout.paragraph('Линии соединяют ориентиры; это не траектория перелёта или дороги. Время, транспорт, расстояния по маршруту и точные точки подтверждаются менеджером.',{size:8.7,leading:12.5,color:PALETTE.muted,after:9});
 layout.paragraph(`Картографическая основа: ${geography?.source?.title??'Natural Earth'}. География показана схематично.`,{size:8,leading:12,color:PALETTE.muted,link:geography?.source?.url,after:17});
 if(!useSidebar)for(const point of points){
  const lines=[{text:point.place?'Географический ориентир нанесён на карту.':'Географическая точка уточняется.',size:9,color:PALETTE.muted,after:4}];
  if(point.place?.source)lines.push({text:`Источник ориентира · ${sourceHost(point.place.source)}`,size:8.5,color:PALETTE.olive,link:point.place.source,after:3});
  layout.card({eyebrow:`ТОЧКА ${String(point.index+1).padStart(2,'0')}`,title:point.name,sections:lines});
 }
}

function costPages(layout){
 const {model}=layout,quote=model.quote;
 const preview=model.mode==='review';
 const estimate=preview?model.estimate:null;
 layout.page('Стоимость и условия',{subtitle:quote?'Данные проверки менеджера по выбранному варианту':'Статус расчёта выбранного путешествия'});
 if(quote){
  layout.card({eyebrow:'ПРОВЕРЕННАЯ СТОИМОСТЬ',title:rubles(quote.amount),titleSize:39,sections:[{text:'Объём услуг и ограничения расчёта приведены ниже. Стоимость действительна в пределах указанного срока.',size:10.5,color:PALETTE.muted}]},{accent:PALETTE.olive});
  layout.rows([
   ['Проверено менеджером',displayDateTime(quote.checkedAt)],
   ['Дата поездки в расчёте',displayDate(quote.travelDate)],
   ['Срок действия',displayDateTime(quote.validUntil)],
  ]);
  layout.paragraph(quote.scope,{label:'Состав проверенного расчёта'});
  layout.paragraph(quote.availability,{label:'Наличие мест'});
  layout.paragraph(quote.terms,{label:'Условия стоимости и оформления'});
  if(preview&&quote.source)layout.paragraph(`Источник проверки · ${sourceHost(quote.source)}`,{label:'Ссылка для менеджера',link:quote.source,color:PALETTE.olive,size:9.5});
 }else if(preview&&estimate){
  const kind=estimate.kind==='demo'?'ДЕМОНСТРАЦИОННЫЙ РАСЧЁТ':'ПРЕДВАРИТЕЛЬНАЯ ОЦЕНКА';
  layout.card({eyebrow:kind,title:`${rubles(estimate.low)} - ${rubles(estimate.high)}`,titleSize:34,sections:[{text:estimate.kind==='demo'?'Условные суммы для проверки сервиса. Не являются тарифами поставщиков и не подтверждают наличие мест.':'Оценка бюджета без подтверждения тарифов и наличия мест. Для клиентского предложения требуется отдельная проверка.',size:10.5,color:PALETTE.warning}]},{accent:PALETTE.warning});
  layout.rows((estimate.lines??[]).map(line=>[line.name,rubles(line.amount)]));
  layout.paragraph(estimate.source,{label:'Основа расчёта',size:10.5,color:PALETTE.muted});
 }else{
  layout.card({eyebrow:'СТАТУС СТОИМОСТИ',title:'Стоимость уточняется',sections:[{text:'Этот документ описывает выбранную идею путешествия. Менеджер отдельно подтвердит стоимость, наличие, состав услуг и условия оформления под ваши даты.'}]},{accent:PALETTE.olive});
 }
 const inclusionHeight=92+[...(model.journey.includes??[]),...(model.journey.excludes??[])].reduce((sum,item)=>sum+layout.wrap(item,BODY_WIDTH-22,'body',10.5).length*15.5+9,0);
 if(layout.y+inclusionHeight>PAGE.bottom)layout.page('Что входит в путешествие',{subtitle:'Состав выбранной идеи и услуги, которые согласуются отдельно'});
 else{layout.gap(5);layout.label('Состав выбранной идеи');}
 layout.paragraph('Перечень ниже сохранён в описании маршрута. Подтверждённый объём услуг определяется составом проверенного расчёта и условиями оформления.',{size:10.5,color:PALETTE.muted,after:16});
 layout.paragraph('Предусмотрено в описании',{font:'title',size:19,color:PALETTE.olive,after:10});
 layout.bullets(model.journey.includes);
 layout.gap(8);
 layout.paragraph('Отдельно или вне состава',{font:'title',size:19,color:PALETTE.olive,after:10});
 layout.bullets(model.journey.excludes);
}

function preparationPages(layout){
 const j=layout.model.journey;
 layout.page('Детали перед путешествием',{subtitle:'Практическая информация из выбранного варианта'});
 layout.card({eyebrow:'СЕЗОН И УСЛОВИЯ',sections:[{text:j.season}]});
 layout.card({eyebrow:'ДОКУМЕНТЫ И ВЪЕЗД',sections:[{text:j.documents}]});
 if(layout.model.mode==='review'){
  const input=layout.model.input;
  const checks=[...(layout.model.issues??[]),...(layout.model.review??[])];
  if(checks.length){layout.label('Проверить перед отправкой');layout.bullets(checks,{color:PALETTE.warning});}
  const brief=[];
  if(input.destination?.trim())brief.push(['Пожелание по направлению',input.destination]);
  if(input.excluded?.trim())brief.push(['Исключённые направления',input.excluded]);
  if(input.formats?.length)brief.push(['Форматы из заявки',input.formats.map(item=>formatNames[item]??item).join(', ')]);
  if(brief.length){layout.gap(8);layout.label('Дополнения к анкете');layout.rows(brief);}
 }
}

function closingPage(layout){
 const {doc,model}=layout;
 layout.base({final:true});
 flower(doc,637,290,172,{opacity:.15,fill:'#ECEBDF',stroke:'#B3B9A5'});
 flower(doc,80,197,25,{fill:PALETTE.paper,stroke:PALETTE.olive});
 layout.wrapped('Ваше путешествие\nначинается с деталей.',61,247,525,{font:'title',size:36,color:PALETTE.olive,leading:41});
 const ending=model.mode==='review'?'Проверьте содержание, маршрут и условия. После согласования подготовьте клиентскую версию предложения.':model.quote?'Обсудите детали с вашим менеджером. После согласования предложения агентство перейдёт к оформлению путешествия.':'Обсудите выбранную идею с вашим менеджером. Следующий шаг - проверка стоимости и наличия на ваши даты.';
 layout.wrapped(ending,64,361,488,{size:11,color:PALETTE.muted,leading:17});
 layout.text(`Подготовлено ${displayDate(model.generatedAt)}`,64,474,{size:8.5,color:PALETTE.taupe});
}

/**
 * Render a sanitized proposal snapshot to a real, self-contained PDF.
 * @param {object} model Authorized immutable snapshot from proposal-data.mjs.
 * @param {{assetRoot:string}} options Local release asset directory.
 * @returns {Promise<Buffer>}
 */
export async function renderProposalPdf(model,{assetRoot}={}){
 if(!assetRoot)throw new TypeError('PDF assetRoot is required.');
 if(!model?.journey||!model?.input||!['review','client'].includes(model.mode))throw new TypeError('Invalid PDF proposal snapshot.');
 const assets=await assetsAt(assetRoot);
 const doc=new PDFDocument({autoFirstPage:false,bufferPages:true,compress:true,font:assets.body,margin:0,pdfVersion:'1.7',info:{Title:`Tiare Travel - ${safeText(model.journey.title)}`,Author:'Tiare Travel',Subject:model.mode==='review'?'Рабочее предложение для менеджера':'Индивидуальное предложение путешествия',Creator:'Tiare Travel',Producer:'Tiare Travel PDF',CreationDate:new Date(model.generatedAt||Date.now())}});
 doc.registerFont('title',assets.title).registerFont('italic',assets.italic).registerFont('body',assets.body);
 const chunks=[];
 let bytes=0;
 const done=new Promise((resolvePromise,reject)=>{doc.on('data',chunk=>{bytes+=chunk.length;if(bytes>MAX_BYTES){doc.destroy(Object.assign(new Error('PDF превышает 12 МБ. Сократите повторяющиеся описания перед экспортом.'),{status:413}));return;}chunks.push(chunk);});doc.once('end',()=>resolvePromise(Buffer.concat(chunks)));doc.once('error',reject);});
 try{
  const layout=makeLayout(doc,model);
  coverPage(layout,assets);
  overviewPages(layout);
  programPages(layout);
  hotelPages(layout);
  logisticsPages(layout);
  mapPages(layout,assets.geography);
  costPages(layout);
  preparationPages(layout);
  closingPage(layout);
  layout.footers();
  doc.end();
 }catch(error){doc.destroy(error);}
 return done;
}
