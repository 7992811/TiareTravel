import { randomUUID } from 'node:crypto';

function postgresSql(sql) { let n=0; return sql.replace(/\?/g,()=>`$${++n}`); }
function mutex() {
 let tail=Promise.resolve();
 return async fn=>{const previous=tail;let release;tail=new Promise(r=>{release=r;});await previous;try{return await fn();}finally{release();}};
}

/** SQLite is deliberately available only to isolated local tests. Production must have PostgreSQL. */
export async function createDatabase(env=process.env) {
 if(env.DATABASE_URL){
  const {Pool}=await import('pg');
  const pool=new Pool({connectionString:env.DATABASE_URL,max:5,connectionTimeoutMillis:10000,idleTimeoutMillis:30000});
  pool.on('error',()=>{console.error('Временная ошибка соединения с базой данных.');});
  const queryWith=client=>async(sql,args=[])=>{const result=await client.query(postgresSql(sql),args);return {rows:result.rows,changes:result.rowCount};};
  const db={dialect:'postgres',query:queryWith(pool),async transaction(fn){const client=await pool.connect();try{await client.query('BEGIN');const result=await fn({dialect:'postgres',query:queryWith(client)});await client.query('COMMIT');return result;}catch(error){await client.query('ROLLBACK');throw error;}finally{client.release();}},async close(){await pool.end();}};
  await migrate(db);return db;
 }
 if(env.NODE_ENV!=='test'||!env.TEST_SQLITE_PATH||env.RENDER||env.RENDER_EXTERNAL_URL)throw new Error('DATABASE_URL обязателен. Резервное локальное хранилище в Render не используется.');
 const {DatabaseSync}=await import('node:sqlite');
 const sqlite=new DatabaseSync(env.TEST_SQLITE_PATH);sqlite.exec('PRAGMA foreign_keys=ON');sqlite.exec('PRAGMA journal_mode=WAL');
 const lock=mutex();
 const directQuery=async(sql,args=[])=>{const stmt=sqlite.prepare(sql);if(/^\s*(SELECT|PRAGMA|WITH)/i.test(sql)){return {rows:stmt.all(...args),changes:0};}const result=stmt.run(...args);return {rows:[],changes:Number(result.changes)};};
 const db={dialect:'sqlite',query:(sql,args)=>lock(()=>directQuery(sql,args)),transaction:fn=>lock(async()=>{sqlite.exec('BEGIN IMMEDIATE');try{const result=await fn({dialect:'sqlite',query:directQuery});sqlite.exec('COMMIT');return result;}catch(error){sqlite.exec('ROLLBACK');throw error;}}),async close(){await lock(()=>sqlite.close());}};
 await migrate(db);return db;
}

const migration1=[
 `CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, client_id TEXT NOT NULL, role TEXT NOT NULL, auth_version TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, expires_at TEXT NOT NULL)`,
 `CREATE INDEX IF NOT EXISTS sessions_expiry_idx ON sessions(expires_at)`,
 `CREATE TABLE IF NOT EXISTS auth_attempts (key_hash TEXT PRIMARY KEY, failures INTEGER NOT NULL, window_at TEXT NOT NULL, blocked_until TEXT NOT NULL)`,
 `CREATE TABLE IF NOT EXISTS travel_requests (id TEXT PRIMARY KEY, client_id TEXT NOT NULL, input_json TEXT NOT NULL, journey_id TEXT, journey_json TEXT, candidate_id TEXT, status TEXT NOT NULL, customer_name TEXT NOT NULL, customer_email TEXT NOT NULL, contact TEXT NOT NULL, notes TEXT NOT NULL, manager_note TEXT NOT NULL DEFAULT '', internal_note TEXT NOT NULL DEFAULT '', candidates_json TEXT NOT NULL, quote_json TEXT, revision INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)`,
 `CREATE INDEX IF NOT EXISTS requests_client_idx ON travel_requests(client_id,created_at)`,
 `CREATE TABLE IF NOT EXISTS request_versions (id TEXT PRIMARY KEY, request_id TEXT NOT NULL REFERENCES travel_requests(id), revision INTEGER NOT NULL, action TEXT NOT NULL, actor_role TEXT NOT NULL, snapshot_json TEXT NOT NULL, created_at TEXT NOT NULL, UNIQUE(request_id,revision))`,
 `CREATE TABLE IF NOT EXISTS travel_catalog (id TEXT PRIMARY KEY, data_json TEXT NOT NULL, updated_at TEXT NOT NULL)`,
 `CREATE TABLE IF NOT EXISTS travel_materials (id TEXT PRIMARY KEY, title TEXT NOT NULL, category TEXT NOT NULL, source_url TEXT NOT NULL, content TEXT NOT NULL, created_at TEXT NOT NULL)`,
 `CREATE TABLE IF NOT EXISTS email_outbox (id TEXT PRIMARY KEY, dedupe_key TEXT NOT NULL UNIQUE, request_id TEXT NOT NULL REFERENCES travel_requests(id), request_revision INTEGER NOT NULL, kind TEXT NOT NULL, mode TEXT NOT NULL, intended_to TEXT NOT NULL, recipient TEXT NOT NULL, subject TEXT NOT NULL, html TEXT NOT NULL, text_body TEXT NOT NULL, reply_to TEXT NOT NULL, status TEXT NOT NULL, provider_id TEXT, attempts INTEGER NOT NULL DEFAULT 0, ambiguous INTEGER NOT NULL DEFAULT 0, next_attempt_at TEXT NOT NULL, lease_until TEXT, last_error TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL, accepted_at TEXT, delivered_at TEXT)`,
 `CREATE INDEX IF NOT EXISTS outbox_queue_idx ON email_outbox(status,next_attempt_at)`,
];

async function migrate(db){
 await db.transaction(async tx=>{
  if(tx.dialect==='postgres')await tx.query('SELECT pg_advisory_xact_lock(724901823)');
  await tx.query('CREATE TABLE IF NOT EXISTS schema_versions (version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL)');
  const current=await tx.query('SELECT version FROM schema_versions WHERE version=?',[1]);
  if(!current.rows.length){for(const sql of migration1)await tx.query(sql);await tx.query('INSERT INTO schema_versions(version,applied_at) VALUES(?,?)',[1,new Date().toISOString()]);}
  const senderVersion=await tx.query('SELECT version FROM schema_versions WHERE version=?',[2]);
  if(!senderVersion.rows.length){await tx.query("ALTER TABLE email_outbox ADD COLUMN sender TEXT NOT NULL DEFAULT ''");await tx.query('INSERT INTO schema_versions(version,applied_at) VALUES(?,?)',[2,new Date().toISOString()]);}
 });
}

export function requestFromRow(row){
 return {id:row.id,clientId:row.client_id,input:JSON.parse(row.input_json),journeyId:row.journey_id,journey:row.journey_json?JSON.parse(row.journey_json):null,candidateId:row.candidate_id,status:row.status,customerName:row.customer_name,customerEmail:row.customer_email,contact:row.contact,notes:row.notes,managerNote:row.manager_note,internalNote:row.internal_note,candidates:JSON.parse(row.candidates_json),quote:row.quote_json?JSON.parse(row.quote_json):null,revision:row.revision,createdAt:row.created_at,updatedAt:row.updated_at};
}
export async function saveVersion(tx,request,action,actorRole){
 await tx.query('INSERT INTO request_versions(id,request_id,revision,action,actor_role,snapshot_json,created_at) VALUES(?,?,?,?,?,?,?)',[randomUUID(),request.id,request.revision,action,actorRole,JSON.stringify(request),request.updatedAt]);
}
export async function updateStoredRequest(tx,request,previousRevision,action,actorRole){
 const result=await tx.query('UPDATE travel_requests SET journey_id=?,journey_json=?,candidate_id=?,status=?,manager_note=?,internal_note=?,candidates_json=?,quote_json=?,revision=?,updated_at=? WHERE id=? AND revision=?',[request.journeyId,request.journey?JSON.stringify(request.journey):null,request.candidateId,request.status,request.managerNote,request.internalNote,JSON.stringify(request.candidates),request.quote?JSON.stringify(request.quote):null,request.revision,request.updatedAt,request.id,previousRevision]);
 if(result.changes!==1){const error=new Error('Заявка уже изменена. Обновите страницу и повторите действие.');error.status=409;throw error;}
 await saveVersion(tx,request,action,actorRole);
}
