import {listenApp} from './app.mjs';

try{await listenApp();}catch{console.error('Tiare Travel не запущен. Проверьте DATABASE_URL и параметры среды. Секреты в журнал не выводятся.');process.exitCode=1;}
