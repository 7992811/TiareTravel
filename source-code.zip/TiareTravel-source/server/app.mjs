import {createServer} from 'node:http';
import {readFile,stat,realpath} from 'node:fs/promises';
import {resolve,extname,sep,relative} from 'node:path';
import {createDatabase} from './db.mjs';
import {sessionForRequest,managerLogin,managerLogout,requireManager} from './auth.mjs';
import {readWorkspace,mutateWorkspace} from './workspace.mjs';
import {createOutbox,appUrl} from './outbox.mjs';
import {parseProposalQuery,loadProposalModel} from './proposal-data.mjs';
import {renderProposalPdf} from './proposal-pdf.mjs';

let pdfInProgress=false;
const maxPdfBytes=16*1024*1024;

const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.webp':'image/webp','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.ico':'image/x-icon','.woff':'font/woff','.woff2':'font/woff2','.txt':'text/plain; charset=utf-8'};
const clientError=(status,message)=>Object.assign(new Error(message),{status});
function securityHeaders(response){
 response.setHeader('X-Content-Type-Options','nosniff');response.setHeader('Referrer-Policy','strict-origin-when-cross-origin');response.setHeader('X-Frame-Options','DENY');response.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=()');response.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'");
}
function sendJson(response,status,body){response.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});response.end(JSON.stringify(body));}
async function requestJson(request){
 if(!String(request.headers['content-type']||'').toLowerCase().startsWith('application/json'))throw clientError(415,'Нужен запрос JSON.');
 if(Number(request.headers['content-length']||0)>150000)throw clientError(413,'Слишком большой запрос.');
 let size=0;const chunks=[];for await(const chunk of request){size+=chunk.length;if(size>150000)throw clientError(413,'Слишком большой запрос.');chunks.push(chunk);}
 try{return JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{throw clientError(400,'Не удалось прочитать запрос.');}
}
function verifyOrigin(request,env){
 if(request.headers['sec-fetch-site']==='cross-site')throw clientError(403,'Запрос с другого сайта отклонён.');
 const origin=request.headers.origin;if(!origin||origin!==appUrl(env))throw clientError(403,'Источник запроса не совпадает с адресом сервиса. Обновите страницу.');
}
async function serveStatic(request,response,url,root){
 let pathname;try{pathname=decodeURIComponent(url.pathname);}catch{throw clientError(400,'Некорректный адрес.');}
 if(pathname.includes('\0')||pathname.split('/').some(part=>part.startsWith('.')))throw clientError(404,'Страница не найдена.');
 let file=resolve(root,'.'+pathname);if(!file.startsWith(root+sep)&&file!==root)throw clientError(404,'Страница не найдена.');
 try{const info=await stat(file);if(!info.isFile())file=resolve(root,'index.html');}catch{if(extname(pathname))throw clientError(404,'Файл не найден.');file=resolve(root,'index.html');}
 const publicName=relative(root,file).split(sep).join('/');
 const permitted=['index.html','favicon.svg','lagoon.webp','robots.txt','tiare-flower.svg','tiare-wordmark.svg','FONT_LICENSES.txt'].includes(publicName)||/^tiare-display(?:-italic)?-(?:latin|cyrillic)\.woff2$/.test(publicName)||/^index-[A-Za-z0-9_-]+\.(js|css)$/.test(publicName)||(/^assets\/[A-Za-z0-9_./-]+$/.test(publicName)&&['.js','.css','.svg','.webp','.png','.jpg','.jpeg','.woff','.woff2'].includes(extname(publicName)));
 if(!permitted)throw clientError(404,'Файл не найден.');
 try{const [rootReal,fileReal]=await Promise.all([realpath(root),realpath(file)]);if(!fileReal.startsWith(rootReal+sep))throw clientError(404,'Файл не найден.');const content=await readFile(fileReal);response.writeHead(200,{'Content-Type':types[extname(file)]||'application/octet-stream','Cache-Control':file.endsWith('index.html')?'no-cache':'public, max-age=3600'});response.end(request.method==='HEAD'?undefined:content);}catch(error){if(error.status)throw error;throw clientError(503,'Интерфейс ещё не собран.');}
}

export async function createApp({env=process.env,database,providers,startOutbox=true,pdfRenderer=renderProposalPdf}={}){
 appUrl(env);const db=database||await createDatabase(env),outbox=createOutbox(db,env,providers),staticRoot=resolve(env.STATIC_DIR||resolve(process.cwd(),'dist'));
 const server=createServer(async(request,response)=>{
  securityHeaders(response);
  try{
   const url=new URL(request.url||'/','http://service.invalid');
   if(url.pathname==='/healthz'&&request.method==='GET'){await db.query('SELECT 1 AS alive');sendJson(response,200,{status:'ok',database:'connected'});return;}
   if(url.pathname.startsWith('/api/')){
    response.setHeader('Cache-Control','no-store');
    if(!['GET','POST'].includes(request.method||''))throw clientError(405,'Метод не поддерживается.');
    if(request.method==='POST')verifyOrigin(request,env);
    const session=await sessionForRequest(db,request,response,env);
    const pdfRoute=url.pathname.match(/^\/api\/requests\/([^/]+)\/proposal\.pdf$/);
    if(pdfRoute){
     requireManager(session);
     if(request.method!=='GET')throw clientError(405,'PDF доступен только для просмотра.');
     const options=parseProposalQuery(pdfRoute[1],url.searchParams);
     const model=await loadProposalModel(db,session,options);
     if(pdfInProgress){response.setHeader('Retry-After','5');throw clientError(429,'Другой PDF ещё формируется. Повторите через несколько секунд.');}
     pdfInProgress=true;
     try{
      const pdf=await pdfRenderer(model,{assetRoot:staticRoot});
      if(!Buffer.isBuffer(pdf)||pdf.length>maxPdfBytes||!pdf.subarray(0,5).equals(Buffer.from('%PDF-')))throw clientError(503,'Не удалось подготовить PDF. Попробуйте повторить позже.');
      const latest=await db.query('SELECT revision FROM travel_requests WHERE id=?',[model.id]);
      if(latest.rows[0]?.revision!==model.revision)throw clientError(409,'Заявка изменилась во время подготовки PDF. Обновите её и повторите выгрузку.');
      if(model.quote&&Date.parse(model.quote.validUntil)<=Date.now())throw clientError(409,'Срок подтверждённой цены истёк во время подготовки PDF. Повторите выгрузку: устаревшая цена будет убрана.');
      response.writeHead(200,{'Content-Type':'application/pdf','Content-Length':pdf.length,'Content-Disposition':`inline; filename="TiareTravel-${model.id.slice(0,8)}-${model.mode}-r${model.revision}.pdf"`,'Cache-Control':'no-store'});
      response.end(pdf);
     }finally{pdfInProgress=false;}
     return;
    }
    if(url.pathname==='/api/workspace'&&request.method==='GET'){sendJson(response,200,await readWorkspace(db,session,env));return;}
    if(url.pathname==='/api/auth/login'&&request.method==='POST'){
     const body=await requestJson(request);if(typeof body?.password!=='string'||body.password.length>1000)throw clientError(400,'Укажите пароль.');await managerLogin(db,request,response,env,session,body.password);sendJson(response,200,{ok:true,role:'manager'});return;
    }
    if(url.pathname==='/api/auth/logout'&&request.method==='POST'){await requestJson(request);await managerLogout(db,response,env,session);sendJson(response,200,{ok:true,role:'client'});return;}
    if(url.pathname==='/api/workspace'&&request.method==='POST'){
     const result=await mutateWorkspace(db,session,env,outbox,await requestJson(request));sendJson(response,200,result);if(startOutbox)outbox.trigger();return;
    }
    throw clientError(404,'Запрос не найден.');
   }
   if(!['GET','HEAD'].includes(request.method||''))throw clientError(405,'Метод не поддерживается.');
   await serveStatic(request,response,url,staticRoot);
  }catch(error){
   if(response.headersSent){response.end();return;}
   const status=Number.isInteger(error?.status)?error.status:503;const message=status>=500&&!error?.status?'Сервис временно недоступен. Ваши сохранённые данные остаются в базе.':error.message;
   sendJson(response,status,{error:message});
  }
 });
 server.requestTimeout=15000;server.headersTimeout=10000;server.keepAliveTimeout=5000;
 if(startOutbox)outbox.start();
 let closed=false;
 return {server,db,outbox,async close(){if(closed)return;closed=true;await outbox.stop();if(server.listening){server.closeIdleConnections();await new Promise((resolve,reject)=>server.close(e=>e?reject(e):resolve()));}await db.close();}};
}

export async function listenApp(env=process.env){
 const app=await createApp({env});const port=Number(env.PORT||3000);if(!Number.isInteger(port)||port<1||port>65535)throw new Error('Некорректный PORT.');
 await new Promise((resolve,reject)=>{app.server.once('error',reject);app.server.listen(port,'0.0.0.0',resolve);});
 console.info(`Tiare Travel: порт ${port}; база ${app.db.dialect}; почта ${env.MAIL_MODE||'test'}.`);
 const shutdown=()=>{void app.close().then(()=>process.exit(0),()=>process.exit(1));};process.once('SIGTERM',shutdown);process.once('SIGINT',shutdown);return app;
}
