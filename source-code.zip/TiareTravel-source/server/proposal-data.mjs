import {z} from 'zod';
import {inputSchema,journeySchema,rankJourneys} from '../lib/travel.ts';
import {requireManager} from './auth.mjs';

const fail=(status,message)=>{throw Object.assign(new Error(message),{status});};
const uuid=z.string().uuid();
const quoteSchema=z.object({
 amount:z.number().int().positive().max(100000000),
 source:z.string().url().refine(value=>{try{const url=new URL(value);return url.protocol==='https:'&&!url.username&&!url.password;}catch{return false;}}),
 checkedAt:z.string(),travelDate:z.string(),scope:z.string().trim().min(15).max(4000),
 availability:z.string().trim().min(10).max(2000),terms:z.string().trim().min(10).max(4000),validUntil:z.string(),
});
const descriptiveKeys=[
 'id','title','subtitle','country','destinations','format','tags','minNights','maxNights','baseNights','changes','needsReview',
 'overview','tradeoff','hotel','program','includes','excludes','logistics','season','documents','updatedAt',
];
const clientInputKeys=['formats','destination','departure','date','nights','adults','children','priorities','pace','cabin','directOnly','maxHours','special','hotelChanges'];

export function parseProposalQuery(id,params){
 if(!uuid.safeParse(id).success)fail(400,'Некорректный номер заявки.');
 const allowed=new Set(['mode','revision','candidateId']);
 for(const key of params.keys())if(!allowed.has(key)||params.getAll(key).length!==1)fail(400,'Некорректные параметры PDF.');
 const mode=params.get('mode'),revisionText=params.get('revision'),candidateId=params.get('candidateId');
 if(!['review','client'].includes(mode))fail(400,'Укажите режим PDF: review или client.');
 if(!revisionText||!/^(0|[1-9][0-9]*)$/.test(revisionText)||!Number.isSafeInteger(Number(revisionText)))fail(400,'Укажите сохранённую версию заявки.');
 if(params.has('candidateId')&&(mode!=='review'||!uuid.safeParse(candidateId).success))fail(400,'Вариант можно указывать только для PDF на проверку.');
 return {id,mode,revision:Number(revisionText),candidateId};
}

function savedJson(value,label){try{return JSON.parse(value);}catch{fail(409,`Не удалось прочитать сохранённые данные: ${label}.`);}}

// Match the current proposal acceptance rules without changing checkedAt or inventing a refreshed quote.
function currentQuote(value,input,status,mode,clock){
 if(!['proposal','agreed'].includes(status)||!value)return null;
 let decoded;try{decoded=JSON.parse(value);}catch{return null;}
 const parsed=quoteSchema.safeParse(decoded);if(!parsed.success)return null;
 const q=parsed.data,date=inputSchema.shape.date.safeParse(q.travelDate),timestamp=clock.getTime();
 const checked=Date.parse(q.checkedAt),expiry=Date.parse(q.validUntil),today=clock.toISOString().slice(0,10);
 if(!date.success||!q.travelDate||q.travelDate<today||q.amount>input.budget)return null;
 if(input.date&&q.travelDate!==input.date)return null;
 if(!Number.isFinite(checked)||checked>timestamp||!Number.isFinite(expiry)||expiry<=timestamp)return null;
 if(expiry>Date.parse(q.travelDate+'T23:59:59.999Z'))return null;
 const result={amount:q.amount,checkedAt:q.checkedAt,travelDate:q.travelDate,scope:q.scope,availability:q.availability,validUntil:q.validUntil,terms:q.terms};
 if(mode==='review')result.source=q.source;
 return result;
}

/** Read one saved request; nothing in this function changes its status, snapshot, or revision. */
export async function loadProposalModel(db,session,options,{clock=new Date()}={}){
 requireManager(session);
 const {id,mode,revision,candidateId}=options;
 // Validate callers beyond the HTTP adapter as well; no permissive default PDF mode.
 const params=new URLSearchParams({mode:String(mode),revision:String(revision)});
 if(candidateId!==null&&candidateId!==undefined)params.set('candidateId',String(candidateId));
 parseProposalQuery(id,params);
 const {rows}=await db.query('SELECT id,input_json,journey_json,candidate_id,status,customer_name,manager_note,quote_json,candidates_json,revision FROM travel_requests WHERE id=?',[id]);
 const row=rows[0];if(!row)fail(404,'Заявка не найдена.');
 if(row.revision!==revision)fail(409,'Заявка уже изменена. Обновите её и сформируйте PDF из актуальной сохранённой версии.');
 if(mode==='client'&&!['selection','pricing','proposal','agreed'].includes(row.status))fail(409,'Сначала опубликуйте одобренный вариант для клиента.');
 const inputResult=inputSchema.safeParse(savedJson(row.input_json,'анкета'));
 if(!inputResult.success)fail(409,'Сохранённая анкета требует проверки перед подготовкой PDF.');
 const input=inputResult.data;
 let selected,reviewNote;
 if(mode==='review'&&candidateId){
  const candidates=savedJson(row.candidates_json,'варианты');
  const candidate=Array.isArray(candidates)?candidates.find(item=>item?.id===candidateId):null;
  if(!candidate)fail(404,'Выбранный вариант не принадлежит этой заявке.');
  selected=candidate.journey;
  if(candidate.reviewNote!==undefined){
   const savedNote=z.string().max(4000).safeParse(candidate.reviewNote);
   if(!savedNote.success)fail(409,'Сохранённый комментарий к варианту требует проверки перед подготовкой PDF.');
   reviewNote=savedNote.data;
  }else reviewNote=candidateId===row.candidate_id?String(row.manager_note||''):'';
 }else{
  if(!row.journey_json)fail(409,mode==='review'?'Выберите сохранённый вариант для проверки.':'Опубликованный маршрут ещё не готов.');
  if(!['selection','pricing','proposal','agreed'].includes(row.status))fail(409,'Для PDF без варианта нужен опубликованный маршрут.');
  selected=savedJson(row.journey_json,'опубликованный маршрут');
 }
 const journeyResult=journeySchema.safeParse(selected);
 if(!journeyResult.success)fail(409,'Сохранённый маршрут требует проверки перед подготовкой PDF.');
 const journey=journeyResult.data;
 const ranked=mode==='review'?rankJourneys([{...journey,active:true}],input)[0]:null;
 const safeJourney=mode==='review'?journey:Object.fromEntries(descriptiveKeys.map(key=>[key,journey[key]]));
 return {
  id:row.id,revision:row.revision,customerName:String(row.customer_name),input:mode==='review'?input:Object.fromEntries(clientInputKeys.map(key=>[key,input[key]])),journey:safeJourney,
  managerNote:reviewNote!==undefined?reviewNote:String(row.manager_note||''),
  // A candidate may have been edited after publication: never attach the published quote to that draft.
  quote:candidateId?null:currentQuote(row.quote_json,input,row.status,mode,clock),
  mode,generatedAt:clock.toISOString(),issues:ranked?.issues||[],review:ranked?.review||[],estimate:ranked?.estimate||null,
 };
}
