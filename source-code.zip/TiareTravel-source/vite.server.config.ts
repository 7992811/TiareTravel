import {defineConfig} from 'vite';
import {fileURLToPath, URL} from 'node:url';

// Portable runtime for uploading from a phone: server and public assets share one directory.
export default defineConfig({
 resolve: {alias: {'@': fileURLToPath(new URL('.', import.meta.url))}},
 ssr: {noExternal: ['zod']},
 build: {
  ssr: 'server/index.mjs', target: 'node24', outDir: 'release', emptyOutDir: false,
  rolldownOptions: {
   external: id => id === 'pg' || id === 'pdfkit' || id.startsWith('node:'),
   output: {entryFileNames: 'tiare-server.mjs', codeSplitting: false}
  }
 }
});
