import { z } from 'zod';
export const formats={beach:'Острова и море',city:'Города и культура',multi:'Несколько мест',safari:'Сафари и природа',cruise:'Круизы и экспедиции'};
export type Format=keyof typeof formats;
export const priorities={quiet:'Тишина и приватность',food:'Гастрономия',culture:'Культура',nature:'Природа',comfort:'Комфорт',activity:'Новые впечатления'};
export type Priority=keyof typeof priorities;
export const inputSchema=z.object({
 formats:z.array(z.enum(['beach','city','multi','safari','cruise'])).max(5),
 destination:z.string().max(150),excluded:z.string().max(150),departure:z.string().min(2).max(100),
 date:z.string().max(10).refine(v=>!v||(/^\d{4}-\d{2}-\d{2}$/.test(v)&&!Number.isNaN(Date.parse(v))&&new Date(v).toISOString().slice(0,10)===v),'Укажите существующую дату'),
 nights:z.number().int().min(2).max(30),adults:z.number().int().min(1).max(8),
 children:z.array(z.number().int().min(0).max(17)).max(6),
 budget:z.number().int().min(50000).max(100000000),
 priorities:z.array(z.enum(['quiet','food','culture','nature','comfort','activity'])).max(3),
 pace:z.enum(['calm','balanced','active']),cabin:z.enum(['economy','business']),
 directOnly:z.boolean(),maxHours:z.number().min(0).max(30),special:z.string().max(1500),
 hotelChanges:z.number().int().min(0).max(10)
});
export type TravelInput=z.infer<typeof inputSchema>;
export const defaultInput:TravelInput={formats:[],destination:'',excluded:'',departure:'Москва',date:'',nights:7,adults:2,children:[],budget:1500000,priorities:['comfort','nature'],pace:'balanced',cabin:'economy',directOnly:false,maxHours:0,special:'',hotelChanges:2};
export type Hotel={name:string;location:string;room:string;description:string;url:string};
export type Day={title:string;activity:string;evening:string;sources?:{title:string;url:string}[]};
export type Journey={
 id:string;title:string;subtitle:string;country:string;destinations:string[];format:Format;tags:Priority[];
 minNights:number;maxNights:number;baseNights:number;changes:number;needsReview:boolean;active:boolean;
 overview:string;tradeoff:string;hotel:Hotel[];program:Day[];includes:string[];excludes:string[];
 logistics:string;season:string;documents:string;perPersonFlight:number;roomNight:number;dailyMeals:number;
 groupLogistics:number;groupExperiences:number;priceKind:'demo'|'estimate';priceSource:string;updatedAt:string;
};
export const journeySchema=z.object({
 id:z.string().min(3).max(100),title:z.string().trim().min(3).max(120),subtitle:z.string().max(200),country:z.string().min(2).max(200),destinations:z.array(z.string().min(2).max(100)).min(1).max(15),
 format:z.enum(['beach','city','multi','safari','cruise']),tags:z.array(z.enum(['quiet','food','culture','nature','comfort','activity'])).max(6),minNights:z.number().int().min(2).max(30),maxNights:z.number().int().min(2).max(30),baseNights:z.number().int().min(2).max(30),changes:z.number().int().min(0).max(10),needsReview:z.boolean(),active:z.boolean(),
 overview:z.string().min(20).max(2000),tradeoff:z.string().min(10).max(1000),hotel:z.array(z.object({name:z.string().min(2).max(200),location:z.string().min(2).max(200),room:z.string().min(3).max(500),description:z.string().min(10).max(1500),url:z.string().url().refine(s=>s.startsWith('https://'))})).min(1).max(10),
 program:z.array(z.object({title:z.string().min(2).max(150),activity:z.string().min(5).max(1500),evening:z.string().min(2).max(1000),sources:z.array(z.object({title:z.string().max(100),url:z.string().url().refine(s=>s.startsWith('https://'))})).max(5).optional()})).min(1).max(30),includes:z.array(z.string().min(2).max(500)).min(1).max(20),excludes:z.array(z.string().min(2).max(500)).min(1).max(20),logistics:z.string().min(10).max(2000),season:z.string().min(10).max(2000),documents:z.string().min(10).max(2000),
 perPersonFlight:z.number().int().nonnegative().max(10000000),roomNight:z.number().int().nonnegative().max(10000000),dailyMeals:z.number().int().nonnegative().max(1000000),groupLogistics:z.number().int().nonnegative().max(10000000),groupExperiences:z.number().int().nonnegative().max(10000000),priceKind:z.enum(['demo','estimate']),priceSource:z.string().min(10).max(1500),updatedAt:z.string()
});
export type Estimate={low:number;high:number;lines:{name:string;amount:number}[];kind:'demo'|'estimate';source:string};
export const money=(v:number)=>new Intl.NumberFormat('ru-RU',{style:'currency',currency:'RUB',maximumFractionDigits:0}).format(v);
export function estimate(j:Journey,input:TravelInput):Estimate|null {
 if(input.children.length)return null;
 const rooms=Math.ceil(input.adults/2);
 const lines=[
 {name:'Перелёты на всех',amount:j.perPersonFlight*input.adults*(input.cabin==='business'?2.5:1)},
 {name:'Проживание · '+input.nights+' ночей · '+rooms+' номер(а)',amount:j.roomNight*input.nights*rooms},
 {name:'Питание вне включённого тарифа',amount:j.dailyMeals*input.nights*input.adults},
 {name:'Трансферы и перемещения',amount:j.groupLogistics*Math.ceil(input.adults/4)},
 {name:'Программа и впечатления',amount:j.groupExperiences*Math.ceil(input.adults/2)}
 ].map(l=>({...l,amount:Math.round(l.amount)}));
 const low=lines.reduce((sum,l)=>sum+l.amount,0);
 return {low,high:Math.ceil(low*1.18/1000)*1000,lines,kind:j.priceKind,source:j.priceSource};
}
export function reviewReasons(input:TravelInput):string[] {
 const r:string[]=[];
 if(input.children.length)r.push('Подтвердить размещение и стоимость для детей указанного возраста');
 if(input.directOnly)r.push('Подтвердить прямые рейсы на выбранные даты');
 if(input.maxHours>0)r.push('Проверить ограничение дороги: не более '+input.maxHours+' часов');
 if(input.special.trim())r.push('Проверить индивидуальные обязательные условия');
 return r;
}
const norm=(s:string)=>s.toLowerCase().replaceAll('ё','е').trim();
const tokens=(s:string)=>norm(s).split(/[,;\n]+/).map(v=>v.trim()).filter(Boolean);
export function rankJourneys(all:Journey[],input:TravelInput){
 return all.filter(j=>j.active).map(j=>{
  const haystack=norm([j.country,...j.destinations,j.title].join(' ')),issues:string[]=[];
  if(input.formats.length&&!input.formats.includes(j.format))issues.push('Другой формат путешествия');
  if(input.destination.trim()&&!tokens(input.destination).some(t=>haystack.includes(t)))issues.push('Другое направление');
  if(tokens(input.excluded).some(t=>haystack.includes(t)))issues.push('Исключённое направление');
  if(input.nights<j.minNights||input.nights>j.maxNights)issues.push('Нужна другая продолжительность');
  if(j.changes>input.hotelChanges)issues.push('Слишком много смен размещения');
  const cost=estimate(j,input);
  if(cost&&cost.high>input.budget)issues.push('Верхняя граница расчёта превышает бюджет');
  const matches=input.priorities.filter(p=>j.tags.includes(p));
  const score=matches.length*10+(input.pace==='calm'&&j.tags.includes('quiet')?6:0)+(input.pace==='active'&&j.tags.includes('activity')?6:0)+(j.changes===0?1:0);
  return {journey:j,estimate:cost,issues,matches,score,review:[...reviewReasons(input),...(j.needsReview?['Проверить стыковки и последовательность этапов маршрута']:[])]};
 }).sort((a,b)=>a.issues.length-b.issues.length||b.score-a.score||(a.estimate?.high??Infinity)-(b.estimate?.high??Infinity));
}
export type RankedJourney=ReturnType<typeof rankJourneys>[number];
export const statuses={new:'Новая заявка',review:'Проверка маршрута',selection:'Идея готова к выбору',pricing:'Проверка стоимости',proposal:'Предложение готово',agreed:'Согласовано'};
export type RequestStatus=keyof typeof statuses;
export type TravelRequest={id:string;input:TravelInput;journeyId:string|null;journey:Journey|null;status:RequestStatus;customerName:string;contact:string;notes:string;managerNote:string;quote:{amount:number;source:string;checkedAt:string;travelDate:string;scope:string;availability:string;validUntil:string;terms:string}|null;revision:number;createdAt:string;updatedAt:string};
export type Material={id:string;title:string;category:string;sourceUrl:string;content:string;createdAt:string};
export function itinerary(j:Journey,nights:number):Day[]{
 return Array.from({length:nights+1},(_,i)=>i===0?{title:'Прибытие и знакомство',activity:'Встреча и переезд к месту проживания. '+j.destinations[0]+'.',evening:'Заселение и спокойный вечер. Время зависит от выбранного перелёта.'}:i===nights?{title:'Возвращение',activity:'Выезд и трансфер к месту отправления.',evening:'Обратный перелёт и время прибытия подтверждаются отдельно.'}:j.program[i-1]??{title:'День в вашем ритме',activity:'Свободное время. Дополнительную прогулку, отдых или впечатление можно согласовать с менеджером.',evening:'Вечер без обязательной программы.'});
}
