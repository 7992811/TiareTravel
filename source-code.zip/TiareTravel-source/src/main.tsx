import React from "react";
import { createRoot } from "react-dom/client";
import TiareApp from "./tiare-app";
import "./styles.css";

createRoot(document.getElementById("root")!).render(<React.StrictMode><TiareApp /></React.StrictMode>);
